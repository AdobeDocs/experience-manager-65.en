#Magento 2 => AEM Connector
========

AEM Connector (Java / AEM project)can be found in the `aem-connector` directory.

The Magento module can be found in the `magento2` directory.

![architecture diagram](aem-connector/documentation/images/architecture.png)


