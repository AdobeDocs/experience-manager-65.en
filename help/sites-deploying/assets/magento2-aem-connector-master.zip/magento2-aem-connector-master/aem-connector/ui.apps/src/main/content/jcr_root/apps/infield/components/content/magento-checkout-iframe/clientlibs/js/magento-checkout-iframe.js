function iframeLoaded() {
      var iFrameID = document.getElementById('magento-checkout');
      if(iFrameID) {
            iFrameID.height = "";
            iFrameID.height = 2000 + "px";
      }

  }

function changeURL( order ) {
    document.location = window.checkoutSuccessUrl + '?order=' + order;
}

// Create IE + others compatible event handler
var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
var eventer = window[eventMethod];
var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";

// Listen to message from child window
eventer(messageEvent,function(e) {
    if(e.data && e.data.from == 'magento'){
        changeURL(e.data.order);
    }
},false);
