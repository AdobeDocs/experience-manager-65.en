package com.infield.magento.identity;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infield.magento.identity.models.AuthCredentials;
import com.infield.magento.identity.models.MagentoCustomer;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;

public class MagentoIdentityConnector {

    private static String server = "http://localhost:8000";

    private static HashMap<Long, String> groups = new HashMap<Long, String>();

    private static final Logger log = LoggerFactory.getLogger(MagentoIdentityConnector.class);

    public  static String getServer() {
        return server;
    }

    public static String JSON = "application/json";

    public void setServer(String server) {
        this.server = server;
    }


    private ObjectMapper mapper = new ObjectMapper();


    public MagentoIdentityConnector() {
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
    }

    public String getAdminToken(String username, String password)throws Exception{
        AuthCredentials authCredentials = new AuthCredentials(username, password);
        String token = Request.Post(server + "/rest/V1/integration/admin/token")
                .bodyString(mapper.writeValueAsString(authCredentials), ContentType.APPLICATION_JSON)
                .execute().returnContent().asString();
        return "Bearer " + token.replace("\"", "");
    }


    public String getToken(String username, String password)throws Exception{
        AuthCredentials authCredentials = new AuthCredentials(username, password);
        String token = Request.Post(server + "/rest/V1/integration/customer/token")
                .bodyString(mapper.writeValueAsString(authCredentials), ContentType.APPLICATION_JSON)
                .execute().returnContent().asString();
        return "Bearer " + token.replace("\"", "");
    }


    public MagentoCustomer getCustomer(String authToken) throws IOException {
        String customerString = Request.Get(server+"/rest/V1/customers/me")
                .addHeader("Authorization", authToken)
                .execute().returnContent().asString();
        return mapper.readValue(customerString, MagentoCustomer.class);
    }

    public MagentoCustomer getCustomerById(String id, String authToken) throws IOException {
        String customerString = Request.Get(server+ "/rest/V1/customers/" + id)
                .addHeader("Authorization", authToken)
                .execute().returnContent().asString();
        return mapper.readValue(customerString, MagentoCustomer.class);
    }


    public String getGroupName(long groupId, String authToken) throws IOException {
        if(groups.containsKey(groupId)){  //todo what happens when the group name changes?
            return groups.get(groupId);
        }else {
           HashMap<String, String> groupMap = getGroupMap(groupId, authToken);
            if(groupMap.containsKey("code")){
                groups.put(groupId, groupMap.get("code"));
                return groupMap.get("code");
            }else{
                return groupId + "";
            }
        }
    }


    private HashMap getGroupMap(long groupId, String authToken) throws IOException {
        String groupString = Request.Get(server+ "/rest/V1/customerGroups/" + groupId)
                .addHeader("Authorization", authToken)
                .execute().returnContent().asString();
        return mapper.readValue(groupString, HashMap.class);
    }

    public MagentoCustomer createCustomer(String simpleCustomer) throws Exception {

        String customerString = Request.Post(server + "/rest/V1/customers")
                .bodyString(simpleCustomer, ContentType.APPLICATION_JSON)
                .execute().returnContent().asString();
        return  mapper.readValue(customerString, MagentoCustomer.class);
    }



}
