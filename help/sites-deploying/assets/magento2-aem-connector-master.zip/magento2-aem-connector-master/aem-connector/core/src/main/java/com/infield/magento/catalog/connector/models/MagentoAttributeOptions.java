package com.infield.magento.catalog.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class MagentoAttributeOptions {

    public final long attribute_id;
    public final String attribute_code;
    public final Option options[];

    @JsonCreator
    @JsonIgnoreProperties(ignoreUnknown = true)
    public MagentoAttributeOptions(@JsonProperty("attribute_id") long attribute_id, @JsonProperty("attribute_code") String attribute_code, @JsonProperty("options") Option[] options){

        this.attribute_id = attribute_id;
        this.attribute_code = attribute_code;
        this.options = options;
    }

    public static final class Apply_to {

        @JsonCreator
        public Apply_to(){
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Option {
        public final String label;
        public final String value;

        @JsonCreator
        public Option(@JsonProperty("label") String label, @JsonProperty("value") String value){
            this.label = label;
            this.value = value;
        }
    }


    public HashMap<String, String> getMap(){

        HashMap<String, String> values = new HashMap<String, String>();
        for(Option option: options){
            values.put(option.value, option.label);
        }
        return values;
    }

}