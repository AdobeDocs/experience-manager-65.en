package com.infield.magento.core.util;

import com.infield.magento.core.connector.MagentoCommerceConnector;
import com.infield.magento.core.connector.model.MagentoAddress;
import com.infield.magento.core.connector.model.MagentoCartItem;
import com.infield.magento.core.connector.model.MagentoPaymentInfo;
import com.infield.magento.core.connector.model.MagentoShippingInfo;

public class OrderTest {
    public static void main(String args[]) {

        try {

            System.out.println("Start of New Test");
            MagentoCommerceConnector connector = new MagentoCommerceConnector();

            String token = null;

            String cartId = connector.initCart(token);

            System.out.println("Initilaized Cart:" + cartId);

            MagentoCartItem cartItem = new MagentoCartItem(new MagentoCartItem.CartItem("24-MB02", 1, cartId));
            connector.addItemToCart(cartId, token, cartItem);

            String[] streets = {"75 Test st"};

            MagentoAddress address = new MagentoAddress("UT", "US", streets, "60647", "Chicago", "Test", "Account", "801-555-1234");
            MagentoShippingInfo shippingInfo = new MagentoShippingInfo(new MagentoShippingInfo.AddressInformation(address, "flatrate", "flatrate"));
            System.out.println("Adding Shipping Info");

            connector.setShippingInfo(cartId, token, shippingInfo);


            MagentoPaymentInfo paymentInfo = new MagentoPaymentInfo(new MagentoPaymentInfo.PaymentMethod("checkmo"), address);

            System.out.println("Adding Payment Info");
            connector.setPaymentInfo(cartId, token, paymentInfo);

            System.out.println("Saving Order");
            String orderId = connector.createOrder(cartId, token);


            System.out.println("Order Created:" + orderId);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Order Error:" + e.getMessage());
        }


    }
}
