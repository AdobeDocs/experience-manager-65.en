package com.infield.magento.catalog.connector;

import com.adobe.cq.commerce.api.CommerceException;
import com.day.cq.commons.jcr.JcrUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infield.magento.catalog.connector.models.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class MagentoConnectorService {

    private static final Logger log = LoggerFactory.getLogger(MagentoConnectorService.class);

    private String server;
    private String username;
    private String password;
    private String authToken;
    private final static int PAGE_SIZE = 2500;
    private static HashMap<String, HashMap> dynamicValues = new HashMap<String, HashMap>();

    private static String[] invalidTags = { "image", "options_container", "has_options", "description", "thumbnail", "small_image","required_options" };

    private ObjectMapper mapper = new ObjectMapper();



    public MagentoConnectorService() {
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
    }

    public MagentoConnectorService(String server, String username, String password) {
        this.server = server;
        this.username = username;
        this.password = password;

        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

        try {
            this.authToken = getToken();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public String getToken() throws Exception{
        com.infield.magento.identity.models.AuthCredentials authCredentials = new com.infield.magento.identity.models.AuthCredentials(username, password);
        log.debug("Getting Admin Token:" + server +" Username:" + username);

        String token = Request.Post(server + "/rest/V1/integration/admin/token")
                .bodyString(mapper.writeValueAsString(authCredentials), ContentType.APPLICATION_JSON)
                .execute().returnContent().asString();
        return "Bearer " + token.replace("\"", "");
    }


    public MagentoProductCategories getProductCategories(String sku){
        log.debug("Getting product cats for SKU: " + sku);
        MagentoProductCategories productCategories = null;
        String response;
        try {
            response = Request.Get(server+"/rest/V1/products/" + sku)
                    .addHeader("Authorization", authToken)
                    .execute().returnContent().asString();
            productCategories =  mapper.readValue(response, MagentoProductCategories.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return productCategories;
    }


    public List<MagentoProduct> getProducts(){
        MagentoProductList response = getProductsbyPage();
        return response.getProducts();
    }


    private MagentoProductList getProductsbyPage(){
        log.debug("Getting products");
        MagentoProductList productList = null;
        String response;
        try {
            //todo: need to make dynamic for larger catalogs
            response = Request.Get(server+"/rest/V1/products?searchCriteria[pageSize]=" + PAGE_SIZE + "&searchCriteria[currentPage]=0")
                    .addHeader("Authorization", authToken)
                    .execute().returnContent().asString();
            productList =  mapper.readValue(response, MagentoProductList.class);
        } catch (IOException e) {
            e.printStackTrace();
            log.error("Error getting Product List: ERROR: " + e.getMessage());
        }
        return productList;
    }


    public  List<MagentoProductVariant> getProductVariants(String sku) throws Exception{
        log.debug("Getting Product Variants for SKU:" + sku );

        List<MagentoProductVariant> productList = null;
        String response;
        try {
            response = Request.Get(server+"/rest/V1/configurable-products/" +sku +"/children")
                    .addHeader("Authorization", authToken)
                    .execute().returnContent().asString();
            productList = mapper.readValue(response, new TypeReference<List<MagentoProductVariant>>(){});
            log.debug("Found " + productList.size() + " variants for:" + sku );
        } catch (IOException e) {
            e.printStackTrace();
            log.error("Error getting Variants for sku:" + sku + " ERROR: " + e.getMessage());
        }
        return productList;
    }


    private HashMap<String, String> getAttributeValuesFromServer(String attributeId) throws Exception{
        log.debug("Getting Value for Attribute:" + attributeId);
        MagentoAttributeOptions options = null;
        String response;
        try {
            response = Request.Get(server+"/rest/V1/products/attributes/" + attributeId)
                    .addHeader("Authorization", authToken)
                    .execute().returnContent().asString();
            options =  mapper.readValue(response, MagentoAttributeOptions.class);
        } catch (IOException e) {
            e.printStackTrace();
            log.error("Error Getting Atrtibute Value form Server:" + attributeId + " ERROR" + e.getMessage());
        }
        return options.getMap();
    }


    public MagentoCategory getCategories(){
        MagentoCategory category = null;
        String response;
        try {
            response = Request.Get(server+"/rest/V1/categories")
                    .addHeader("Authorization", authToken)
                    .execute().returnContent().asString();
            category =  mapper.readValue(response, MagentoCategory.class);
        } catch (IOException e) {
            e.printStackTrace();
            log.error("Error Getting Cats from Server: ERROR" + e.getMessage());
        }
        return category;
    }


    public MagentoProductList updateProductList(String dateString){
        MagentoProductList productList = null;
        String response;

        StringBuilder url = new StringBuilder();
        url.append(server)
        .append("/rest/V1/products?")
        .append("searchCriteria[filter_groups][0][filters][1][field]=updated_at")
        .append("&")
        .append("searchCriteria[filter_groups][0][filters][1][condition_type]=gt")
        .append("&")
        .append("searchCriteria[filter_groups][0][filters][1][value]=")
        .append(dateString);

        try {
            response = Request.Get(url.toString())
                    .addHeader("Authorization", authToken)
                    .execute().returnContent().asString();
            productList =  mapper.readValue(response, MagentoProductList.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return productList;
    }

    public  String getAttributeValue(String attributeCode, String attributeId) {
        HashMap<String, String> hashMap;
        if(dynamicValues.containsKey(attributeCode)){
            hashMap = dynamicValues.get(attributeCode);
        }else{
            try {
                hashMap = this.getAttributeValuesFromServer(attributeCode);
                dynamicValues.put(attributeCode, hashMap);
            } catch (Exception e) {
                return null;
            }
        }
        return hashMap.get(attributeId);
    }



    public String[] getTags(MagentoProduct product){
        Map<String, String> customAttributes = product.getCustomAttributes();
        ArrayList<String> tags = new ArrayList();
        List invalid = Arrays.asList(invalidTags);
        for(String key: customAttributes.keySet()){
            if(!invalid.contains(key)){
                String value = customAttributes.get(key);
                if (value.contains(",")) {
                    String multiValues[] = value.split(",");
                    for(String singleValue: multiValues){
                        String tagValue = this.getAttributeValue(key, singleValue);
                        if (tagValue!=null){
                            String tagPrefix = "magento2:";
                            String tagName = createValidJcrName(key);
                            tags.add(tagPrefix + tagName + "/" + createValidJcrName(tagValue));
                        }
                    }
                }else{
                    String tagValue = this.getAttributeValue(key, value);
                    if (tagValue!=null){
                        String tagPrefix = "magento2:";
                        String tagName = createValidJcrName(key);
                        tags.add(tagPrefix + tagName + "/" + createValidJcrName(tagValue));
                    }
                }
            }
        }

        //todo AFTER Magento2 adds Category IDS to Product List call this can be removed.
        List<String> catIds = getProductCategories(product.sku).getCategoryIds();
        for(String categoryId: catIds){
            tags.add("magento2:category/" + categoryId);
        }

        return tags.toArray(new String[tags.size()]);
    }


    public MagentoProduct getProduct(String authToken, String sku) throws CommerceException {
        try {
            String response = Request.Get(server+"/rest/V1/products/" + sku)
                    .addHeader("Authorization", authToken)
                    .execute().returnContent().asString();
            return mapper.readValue(response, MagentoProduct.class);
        } catch (IOException e) {
            throw new CommerceException(e.getMessage());
        }
    }

    private  String createValidJcrName(String tagName) {
        final String validName =
            StringUtils.lowerCase(JcrUtil.createValidName(StringUtils.strip(tagName)));
        return validName;
    }

}
