package com.infield.magento.core.connector.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
public final class MagentoShippingResponse {
    public final Payment_method payment_methods[];
    public final Totals totals;

    @JsonCreator
    public MagentoShippingResponse(@JsonProperty("payment_methods") Payment_method[] payment_methods, @JsonProperty("totals") Totals totals){
        this.payment_methods = payment_methods;
        this.totals = totals;
    }

    public static final class Payment_method {
        public final String code;
        public final String title;

        @JsonCreator
        public Payment_method(@JsonProperty("code") String code, @JsonProperty("title") String title){
            this.code = code;
            this.title = title;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Totals {
        public final double grand_total;
        public final double base_grand_total;
        public final long subtotal;
        public final long base_subtotal;
        public final double discount_amount;
        public final double base_discount_amount;
        public final double subtotal_with_discount;
        public final double base_subtotal_with_discount;
        public final long shipping_amount;
        public final long base_shipping_amount;
        public final long shipping_discount_amount;
        public final long base_shipping_discount_amount;
        public final long tax_amount;
        public final long base_tax_amount;
        public final Weee_tax_applied_amount weee_tax_applied_amount;
        public final long shipping_tax_amount;
        public final long base_shipping_tax_amount;
        public final long subtotal_incl_tax;
        public final long shipping_incl_tax;
        public final long base_shipping_incl_tax;
        public final String base_currency_code;
        public final String quote_currency_code;
        public final long items_qty;
        public final Item items[];
        public final Total_segment total_segments[];

        @JsonCreator
        public Totals(@JsonProperty("grand_total") double grand_total, @JsonProperty("base_grand_total") double base_grand_total, @JsonProperty("subtotal") long subtotal, @JsonProperty("base_subtotal") long base_subtotal, @JsonProperty("discount_amount") double discount_amount, @JsonProperty("base_discount_amount") double base_discount_amount, @JsonProperty("subtotal_with_discount") double subtotal_with_discount, @JsonProperty("base_subtotal_with_discount") double base_subtotal_with_discount, @JsonProperty("shipping_amount") long shipping_amount, @JsonProperty("base_shipping_amount") long base_shipping_amount, @JsonProperty("shipping_discount_amount") long shipping_discount_amount, @JsonProperty("base_shipping_discount_amount") long base_shipping_discount_amount, @JsonProperty("tax_amount") long tax_amount, @JsonProperty("base_tax_amount") long base_tax_amount, @JsonProperty("weee_tax_applied_amount") Weee_tax_applied_amount weee_tax_applied_amount, @JsonProperty("shipping_tax_amount") long shipping_tax_amount, @JsonProperty("base_shipping_tax_amount") long base_shipping_tax_amount, @JsonProperty("subtotal_incl_tax") long subtotal_incl_tax, @JsonProperty("shipping_incl_tax") long shipping_incl_tax, @JsonProperty("base_shipping_incl_tax") long base_shipping_incl_tax, @JsonProperty("base_currency_code") String base_currency_code, @JsonProperty("quote_currency_code") String quote_currency_code, @JsonProperty("items_qty") long items_qty, @JsonProperty("items") Item[] items, @JsonProperty("total_segments") Total_segment[] total_segments){
            this.grand_total = grand_total;
            this.base_grand_total = base_grand_total;
            this.subtotal = subtotal;
            this.base_subtotal = base_subtotal;
            this.discount_amount = discount_amount;
            this.base_discount_amount = base_discount_amount;
            this.subtotal_with_discount = subtotal_with_discount;
            this.base_subtotal_with_discount = base_subtotal_with_discount;
            this.shipping_amount = shipping_amount;
            this.base_shipping_amount = base_shipping_amount;
            this.shipping_discount_amount = shipping_discount_amount;
            this.base_shipping_discount_amount = base_shipping_discount_amount;
            this.tax_amount = tax_amount;
            this.base_tax_amount = base_tax_amount;
            this.weee_tax_applied_amount = weee_tax_applied_amount;
            this.shipping_tax_amount = shipping_tax_amount;
            this.base_shipping_tax_amount = base_shipping_tax_amount;
            this.subtotal_incl_tax = subtotal_incl_tax;
            this.shipping_incl_tax = shipping_incl_tax;
            this.base_shipping_incl_tax = base_shipping_incl_tax;
            this.base_currency_code = base_currency_code;
            this.quote_currency_code = quote_currency_code;
            this.items_qty = items_qty;
            this.items = items;
            this.total_segments = total_segments;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static final class Weee_tax_applied_amount {

            @JsonCreator
            public Weee_tax_applied_amount(){
            }
        }


        @JsonIgnoreProperties(ignoreUnknown = true)
        public static final class Item {
            public final long item_id;
            public final long price;
            public final long base_price;
            public final long qty;
            public final long row_total;
            public final long base_row_total;
            public final long row_total_with_discount;
            public final long tax_amount;
            public final long base_tax_amount;
            public final long tax_percent;
            public final long discount_amount;
            public final long base_discount_amount;
            public final long discount_percent;
            public final long price_incl_tax;
            public final long base_price_incl_tax;
            public final long row_total_incl_tax;
            public final long base_row_total_incl_tax;
            public final String options;
            public final String name;

            @JsonCreator
            public Item(@JsonProperty("item_id") long item_id, @JsonProperty("price") long price, @JsonProperty("base_price") long base_price, @JsonProperty("qty") long qty, @JsonProperty("row_total") long row_total, @JsonProperty("base_row_total") long base_row_total, @JsonProperty("row_total_with_discount") long row_total_with_discount, @JsonProperty("tax_amount") long tax_amount, @JsonProperty("base_tax_amount") long base_tax_amount, @JsonProperty("tax_percent") long tax_percent, @JsonProperty("discount_amount") long discount_amount, @JsonProperty("base_discount_amount") long base_discount_amount, @JsonProperty("discount_percent") long discount_percent, @JsonProperty("price_incl_tax") long price_incl_tax, @JsonProperty("base_price_incl_tax") long base_price_incl_tax, @JsonProperty("row_total_incl_tax") long row_total_incl_tax, @JsonProperty("base_row_total_incl_tax") long base_row_total_incl_tax, @JsonProperty("options") String options, @JsonProperty("name") String name){
                this.item_id = item_id;
                this.price = price;
                this.base_price = base_price;
                this.qty = qty;
                this.row_total = row_total;
                this.base_row_total = base_row_total;
                this.row_total_with_discount = row_total_with_discount;
                this.tax_amount = tax_amount;
                this.base_tax_amount = base_tax_amount;
                this.tax_percent = tax_percent;
                this.discount_amount = discount_amount;
                this.base_discount_amount = base_discount_amount;
                this.discount_percent = discount_percent;
                this.price_incl_tax = price_incl_tax;
                this.base_price_incl_tax = base_price_incl_tax;
                this.row_total_incl_tax = row_total_incl_tax;
                this.base_row_total_incl_tax = base_row_total_incl_tax;
                this.options = options;
                this.name = name;
            }
        }


        @JsonIgnoreProperties(ignoreUnknown = true)
        public static final class Total_segment {
            public final String code;
            public final String title;
            public final double value;
            public final Extension_attributes extension_attributes;
            public final String area;

            @JsonCreator
            public Total_segment(@JsonProperty("code") String code, @JsonProperty("title") String title, @JsonProperty("value") double value, @JsonProperty(value="extension_attributes", required=false) Extension_attributes extension_attributes, @JsonProperty(value="area", required=false) String area){
                this.code = code;
                this.title = title;
                this.value = value;
                this.extension_attributes = extension_attributes;
                this.area = area;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static final class Extension_attributes {
                public final Tax_grandtotal_detail tax_grandtotal_details[];

                @JsonCreator
                public Extension_attributes(@JsonProperty("tax_grandtotal_details") Tax_grandtotal_detail[] tax_grandtotal_details){
                    this.tax_grandtotal_details = tax_grandtotal_details;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static final class Tax_grandtotal_detail {

                    @JsonCreator
                    public Tax_grandtotal_detail(){
                    }
                }
            }
        }
    }
}
