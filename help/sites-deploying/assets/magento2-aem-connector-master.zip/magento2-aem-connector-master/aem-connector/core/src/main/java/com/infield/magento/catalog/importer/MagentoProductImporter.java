package com.infield.magento.catalog.importer;

import com.adobe.cq.commerce.pim.api.ProductImporter;
import com.adobe.cq.commerce.pim.common.AbstractProductImporter;
import com.adobe.granite.workflow.launcher.ConfigEntry;
import com.infield.magento.catalog.connector.MagentoConnectorService;
import com.infield.magento.catalog.connector.models.MagentoProduct;
import com.infield.magento.catalog.connector.models.MagentoProductVariant;
import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.jackrabbit.commons.JcrUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.event.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

@Component(metatype = true, label = "magento importer",description =" product importer for magento")
@Service
@Properties(value = {
        @Property(name = "service.description", value = "Magento 2 Product Importer"),
        @Property(name = "service.vendor", value = "Infield Digital"),
        @Property(name = "commerceProvider", value = "magento", propertyPrivate = true)
})
public class MagentoProductImporter extends AbstractProductImporter implements ProductImporter {

    private static final Logger log = LoggerFactory.getLogger(MagentoProductImporter.class);

    private List<MagentoProduct> products;

    private HashMap<String, MagentoProduct> comfigurableItems = new HashMap<String, MagentoProduct>();
    private HashMap<String, MagentoProduct> simpleItems = new HashMap<String, MagentoProduct>();
    private MagentoConnectorService magentoConnectorService;

    // Flag to add the imported products to a collection
    private boolean addToCollection;

    // Path of the product collection to which the imported products will be added or removed
    private String collectionPath;


    private final String productsRoot = "/etc/catalog/products/";

    @Override
    protected boolean disableWorkflowPredicate(ConfigEntry workflowConfigEntry) {
        return workflowConfigEntry.getGlob().startsWith(productsRoot);
    }


    public MagentoProductImporter() {
        super();
    }

    public MagentoProductImporter(MagentoConnectorService magentoConnectorService) {
        super();
        this.magentoConnectorService = magentoConnectorService;
    }


    @Override
    protected boolean validateInput(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {

        collectionPath = request.getParameter("collectionPath");
        addToCollection = "true".equals(request.getParameter("addToCollection"));

        String provider = request.getParameter("provider");
        if (StringUtils.isEmpty(provider)) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "No catalog provider specified.");
            return false;
        }

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String server = request.getParameter("server");

        magentoConnectorService = new MagentoConnectorService(server, username, password);


        products = magentoConnectorService.getProducts();


        //Separate Products into Complex and Simple

        for(MagentoProduct product: products){
            if(product.type_id.equalsIgnoreCase("configurable")){
                comfigurableItems.put(product.sku, product);
            }else{
                simpleItems.put(product.sku, product);
            }
        }

        String storePath = request.getParameter("storePath");
        String storeName = request.getParameter("storeName");

        if (StringUtils.isEmpty(storePath) && StringUtils.isEmpty(storeName)) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Destination not specified.");
            return false;
        }

        return true;
    }

    @Override
    protected void doImport(ResourceResolver resourceResolver, Node storeRoot, boolean incrementalImport)
            throws RepositoryException, IOException {

        String storePath = storeRoot.getPath();
        //iterate through Complex Items first and then account for any children
        int count = 0;
        int size = comfigurableItems.values().size();
        for(MagentoProduct item: comfigurableItems.values()){
            count++;
            try {
                long startProductAdd = System.currentTimeMillis();
                Node productNode = addProduct(resourceResolver, storePath, item.sku, item);
                log.debug("Time to Add Complex Product:" + (System.currentTimeMillis() - startProductAdd) + " Milliseconds. "+count+" of "+size);

            BigDecimal price = new BigDecimal(0);

            List<MagentoProductVariant> variants = magentoConnectorService.getProductVariants(item.sku);

                for(MagentoProductVariant variant: variants){
                   long start = System.currentTimeMillis();
                    addVariation(resourceResolver, storePath, item, variant);
                    log.debug("Time to Add Variant:" + (System.currentTimeMillis() - start) + " Milliseconds");

                    //base products don't have price so lets find the cheapest one from the variants.
                    if(price.doubleValue() <= 0 || variant.price.doubleValue() < price.doubleValue()){
                        price = variant.price;
                    }
                    simpleItems.remove(variant.sku); // After Adding variant child to Parent node remove it from the simple list so it is not added twice
                }

                //Set the Price
                if(item.price.doubleValue() == 0 ) {
                    String priceString = price + "";
                    if (StringUtils.isNotEmpty(priceString)) {
                        productNode.setProperty("price", new BigDecimal(priceString));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                log.error("Error Importing Product:" + item.sku);
            }

        }

        // After Adding the Configurable Products lets add the simple ones
        count = 0;
        size = simpleItems.values().size();
        for(MagentoProduct item: simpleItems.values()){
            count++;
            long start = System.currentTimeMillis();
            addProduct(resourceResolver, storePath, item.sku, item);
            log.debug("Time to Add " + item.sku + "Product:" + (System.currentTimeMillis() - start) + " Milliseconds. "+count+" of "+size);
        }


    }
    public Node addProduct(ResourceResolver resourceResolver, String storePath, String sku, MagentoProduct product) throws RepositoryException {
        String path = getProductPath(storePath, sku);
        Node productNode = createProduct(path, resourceResolver.adaptTo(Session.class));

            productNode.setProperty("baseSku", sku);
            //SET DEFAULT PROPERTIES
            setProperties(resourceResolver, productNode, product, null, false);
            //ADD TAGS
            productNode.addMixin("cq:Taggable");
            String tags[]  = magentoConnectorService.getTags(product);
            createMissingTags(resourceResolver, tags);
            productNode.setProperty("cq:tags", tags);


        return productNode;

    }


    public void updateProduct(ResourceResolver resourceResolver, String storePath, String sku, MagentoProduct product) {

        String path = getProductPath(storePath, sku);
        try {

            Resource productResource = resourceResolver.getResource(getProductPath(storePath, sku));
            Resource storeResource = resourceResolver.getResource(storePath);
            if (productResource == null) {
                throw new RuntimeException("product doesn't exist");
            }

            Node storeRootNode = storeResource.adaptTo(Node.class);
            Node productNode = productResource.adaptTo(Node.class);
            this.openThrottle(storeRootNode);
            //SET DEFAULT PROPERTIES
            setProperties(resourceResolver, productNode, product, null, true);

            //ADD TAGS
            productNode.addMixin("cq:Taggable");
            String tags[] = magentoConnectorService.getTags(product);
            createMissingTags(resourceResolver, tags);
            productNode.setProperty("cq:tags", tags);

        } catch (Exception e) {
            log.error("Failed to update product " + path, e);
        }

    }



    public void deleteProduct(ResourceResolver resourceResolver, String storePath, String sku) {
        try {
            Resource product = resourceResolver.getResource(getProductPath(storePath, sku));
            if (product == null) {
                throw new RuntimeException("product doesn't exist");
            }
            Node productNode = product.adaptTo(Node.class);

            productDeleted(productNode);

            productNode.remove();
        } catch (Exception e) {
            logMessage("ERROR deleting " + sku, true);
            log.error("Failed to delete product " + sku, e);
        }
    }

    public void setProperties(ResourceResolver resourceResolver, Node node, MagentoProduct product, String language, boolean update) throws RepositoryException {
        if (update) {
            // Clear any existing, non-system properties:
            for (PropertyIterator existingProps = node.getProperties(); existingProps.hasNext(); ) {
                javax.jcr.Property prop = (javax.jcr.Property) existingProps.next();
                String propName = prop.getName();
                if (propName.startsWith("jcr:title") || propName.startsWith("jcr:description") || propName.equals("cq:tags")) {
                    prop.remove();
                } else if (!propName.startsWith("jcr:") && !propName.startsWith("sling:") && !propName.startsWith("cq:")
                        && !prop.getDefinition().isAutoCreated() && !prop.getDefinition().isProtected()) {
                    prop.remove();
                }
            }
            // Remove any existing image:
            if (node.hasNode("image")) {
                node.getNode("image").remove();
            }
            // Remove any existing asset:
            if (node.hasNode("assets")) {
                node.getNode("assets").remove();
            }
        }

        String title = product.name;
        if (StringUtils.isNotEmpty(title)) {
            String name = "jcr:title";
            if (language != null) {
                name += "." + language;
            }
            node.setProperty(name, title);
        }
        String sku = product.sku;
        if (StringUtils.isNotEmpty(sku)) {
            node.setProperty("identifier", sku);
        }
        String price = product.price + "";

        if (StringUtils.isNotEmpty(price)) {
            node.setProperty("price", product.price);
        }
        if (!update) {
            String imageUrl = product.getAttribute("image");
            log.debug("Image asset is:" + imageUrl);
            createAssets(node, imageUrl);
        }
        if(update){
            String imageUrl = product.getPrimaryImagePath();
            log.debug("Image asset is:" + imageUrl);
            createAssets(node, imageUrl);
        }



        String summary = product.getAttribute("description");
        if (StringUtils.isNotEmpty(summary)) {
            String name = "summary";
            node.setProperty(name, summary);

        }

        //todo: need to figure out which field should be "description"
        String description = "";
        String name = "jcr:description";
        if (language != null) {
            name += "." + language;
        }
        node.setProperty(name, description);

    }

    protected void createAssets(Node productNode, String imgUrl) throws RepositoryException {

        Node imageNode = createImage(productNode);
        imageNode.setProperty("fileReference", "/content/dam/magento2/product" + imgUrl);
        checkpoint(imageNode.getSession(), false);

            Node baseProduct = getBaseProduct(productNode);
            if (baseProduct != null) {
                logEvent("com/adobe/cq/commerce/pim/PRODUCT_MODIFIED", baseProduct.getPath());
            }

    }

    //todo: this is here because the parent used the private messages list to store messages without
    //todo:     calling this.run we can't instantiate that variable. Wo we've taken the use of message out
    protected Node createImage(Node product) throws RepositoryException {
        Node image = product.addNode("image", "nt:unstructured");
        image.setProperty("sling:resourceType", "commerce/components/product/image");
        image.setProperty("jcr:lastModified", Calendar.getInstance());
        Node baseProduct = this.getBaseProduct(product);

        this.checkpoint(product.getSession(), false);
        return image;
    }


    protected void addVariation(ResourceResolver resourceResolver, String storePath, MagentoProduct parentProduct, MagentoProductVariant variant) {
        String color = magentoConnectorService.getAttributeValue("color", variant.getAttributeId("color"));
        try {

            Resource parent = resourceResolver.getResource(getProductPath(storePath, parentProduct.sku));

            if (parent == null) {
                throw new RuntimeException("parent doesn't exist");
            }
            Node variantNode;
            Resource varentResource = parent.getChild(color);
            if(varentResource != null){
                variantNode = varentResource.adaptTo(Node.class);
            }else{
                variantNode = createVariant(parent.adaptTo(Node.class), color);
                variantNode.setProperty("colorCode", variant.getAttributeId("color"));
                variantNode.setProperty("jcr:title", parentProduct.name + " (" + color + ")");
                variantNode.setProperty("identifier", variant.sku);
                variantNode.setProperty("color", magentoConnectorService.getAttributeValue("color", variant.getAttributeId("color")));
                String imageUrl = variant.getAttributeId("image");
                log.debug("Image asset is:" + imageUrl);
                createAssets(variantNode, imageUrl);
                registerVariantAxis(variantNode, "color");
            }

            String sizeCode = variant.getAttributeId("size");

            log.debug("Size variant for " + variant.sku +" :" + sizeCode);

            if(sizeCode != null){
                createSizeVariant(resourceResolver, variantNode, magentoConnectorService.getAttributeValue("size", sizeCode), sizeCode, variant);
            }
        } catch (Exception e) {
            logMessage("ERROR adding variation " + variant.sku, true);
            log.error("Failed to create variation " + variant.sku, e);
        }
    }


    protected void createSizeVariant(ResourceResolver resourceResolver, Node node, String size, String sizeCode, MagentoProductVariant variant){

        try {
                Node variantNode = createVariant(node, "size-" + mangleName(size));
                variantNode.setProperty("size", size.trim());
            variantNode.setProperty("sizeCode", sizeCode);
            variantNode.setProperty("price", variant.price);
            variantNode.setProperty("identifier", variant.sku);
                registerVariantAxis(variantNode, "size");
            } catch (Exception e) {
                logMessage("ERROR creating size " + size, true);
                log.error("Failed to create size " + size, e);
            }
    }



    protected void registerVariantAxis(Node product, String axis) {
        try {
            while (product.getProperty("cq:commerceType").getString().equals("variant")) {
                product = product.getParent();
            }

            String[] axes;
            if (product.hasProperty("cq:productVariantAxes")) {
                Value[] values = product.getProperty("cq:productVariantAxes").getValues();
                axes = new String[values.length + 1];
                for (int i = 0; i < values.length; i++) {
                    axes[i] = values[i].getString();
                    if (axes[i].equals(axis)) {
                        // already registered
                        return;
                    }
                }
                axes[values.length] = axis;
            } else {
                axes = new String[1];
                axes[0] = axis;
            }
            product.setProperty("cq:productVariantAxes", axes);
        } catch (RepositoryException e) {
            log.error("Failed to register variant axis " + axis, e);
        }
    }


    protected String getProductPath(String storePath, String sku) {

        String productSKU = sku;
        boolean variation = false;

        if (sku.contains(".")) {
            productSKU = sku.substring(0, sku.indexOf("."));
            variation = true;
        }

        String path = storePath + "/" + sku.substring(0, 2) + "/" + sku.substring(0, 4) + "/" + productSKU;
        if (variation) {
            path += "/" + sku;
        }
        return path;
    }
}

