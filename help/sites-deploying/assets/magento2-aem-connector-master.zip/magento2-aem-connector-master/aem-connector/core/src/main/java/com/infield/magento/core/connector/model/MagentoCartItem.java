package com.infield.magento.core.connector.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public final class MagentoCartItem {
    public final CartItem cartItem;

    @JsonCreator
    public MagentoCartItem(@JsonProperty("cartItem") CartItem cartItem){
        this.cartItem = cartItem;
    }

    public static final class CartItem {
        public final String sku;
        public final long qty;
        public final String quote_id;

        @JsonCreator
        public CartItem(@JsonProperty("sku") String sku, @JsonProperty("qty") long qty, @JsonProperty("quote_id") String quote_id){
            this.sku = sku;
            this.qty = qty;
            this.quote_id = quote_id;
        }
    }
}