package com.infield.magento.core.connector.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("ALL")
public final class MagentoShippingInfo {
    public final AddressInformation addressInformation;

    @JsonCreator
    public MagentoShippingInfo(@JsonProperty("addressInformation") AddressInformation addressInformation){
        this.addressInformation = addressInformation;
    }

    public static final class AddressInformation {
        public final MagentoAddress shipping_address;
        public final String shipping_method_code;
        public final String shipping_carrier_code;

        @JsonCreator
        public AddressInformation(@JsonProperty("shipping_address") MagentoAddress shipping_address, @JsonProperty("shipping_method_code") String shipping_method_code, @JsonProperty("shipping_carrier_code") String shipping_carrier_code){
            this.shipping_address = shipping_address;
            this.shipping_method_code = shipping_method_code;
            this.shipping_carrier_code = shipping_carrier_code;
        }
    }
}
