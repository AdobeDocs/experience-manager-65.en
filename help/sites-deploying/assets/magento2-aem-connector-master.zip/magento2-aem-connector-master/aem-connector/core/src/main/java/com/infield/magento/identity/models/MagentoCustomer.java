package com.infield.magento.identity.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
public final class MagentoCustomer {

    public static final String GENDER_FEMALE_ID = "2";
    public static final String GENDER_FEMALE_VALUE = "female";
    public static final String GENDER_MALE_ID = "1";
    public static final String GENDER_MALE_VALUE = "male";

    public final long id;
    public final long group_id;
    public final String default_billing;
    public final String default_shipping;
    public final String created_at;
    public final String updated_at;
    public final String created_in;
    public final String email;
    public final String firstname;
    public final String lastname;
    public final String gender;
    public final long store_id;
    public final long website_id;
    public final Addresse addresses[];

    @JsonCreator
    public MagentoCustomer(@JsonProperty("id") long id, @JsonProperty("group_id") long group_id, @JsonProperty("default_billing") String default_billing, @JsonProperty("default_shipping") String default_shipping, @JsonProperty("created_at") String created_at, @JsonProperty("updated_at") String updated_at, @JsonProperty("created_in") String created_in, @JsonProperty("email") String email, @JsonProperty("firstname") String firstname, @JsonProperty("lastname") String lastname, @JsonProperty("gender") String gender, @JsonProperty("store_id") long store_id, @JsonProperty("website_id") long website_id, @JsonProperty("addresses") Addresse[] addresses){
        this.id = id;
        this.group_id = group_id;

        if(gender.equals(GENDER_FEMALE_ID)){
            this.gender = GENDER_FEMALE_VALUE;
        }
        else if(gender.equals(GENDER_MALE_ID)){
            this.gender = GENDER_MALE_VALUE;
        }
        else{
            this.gender = "";
        }

        this.default_billing = default_billing;
        this.default_shipping = default_shipping;
        this.created_at = created_at;
        this.updated_at = updated_at;
        this.created_in = created_in;
        this.email = email;
        this.firstname = firstname;
        this.lastname = lastname;
        this.store_id = store_id;
        this.website_id = website_id;
        this.addresses = addresses;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Addresse {
        public final long id;
        public final long customer_id;
        public final Region region;
        public final long region_id;
        public final String country_id;
        public final String[] street;
        public final String company;
        public final String telephone;
        public final String postcode;
        public final String city;
        public final String firstname;
        public final String lastname;
        public final boolean default_shipping;
        public final boolean default_billing;

        @JsonCreator
        public Addresse(@JsonProperty("id") long id, @JsonProperty("customer_id") long customer_id, @JsonProperty("region") Region region, @JsonProperty("region_id") long region_id, @JsonProperty("country_id") String country_id, @JsonProperty("street") String[] street, @JsonProperty("company") String company, @JsonProperty("telephone") String telephone, @JsonProperty("postcode") String postcode, @JsonProperty("city") String city, @JsonProperty("firstname") String firstname, @JsonProperty("lastname") String lastname, @JsonProperty("default_shipping") boolean default_shipping, @JsonProperty("default_billing") boolean default_billing){
            this.id = id;
            this.customer_id = customer_id;
            this.region = region;
            this.region_id = region_id;
            this.country_id = country_id;
            this.street = street;
            this.company = company;
            this.telephone = telephone;
            this.postcode = postcode;
            this.city = city;
            this.firstname = firstname;
            this.lastname = lastname;
            this.default_shipping = default_shipping;
            this.default_billing = default_billing;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static final class Region {
            public final String region_code;
            public final String region;
            public final long region_id;

            @JsonCreator
            public Region(@JsonProperty("region_code") String region_code, @JsonProperty("region") String region, @JsonProperty("region_id") long region_id){
                this.region_code = region_code;
                this.region = region;
                this.region_id = region_id;
            }
        }
    }
}
