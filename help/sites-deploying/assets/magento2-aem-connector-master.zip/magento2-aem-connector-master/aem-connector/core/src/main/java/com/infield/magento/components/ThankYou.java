package com.infield.magento.components;

import com.adobe.cq.commerce.api.CommerceException;
import com.adobe.cq.commerce.api.CommerceService;
import com.adobe.cq.commerce.api.CommerceSession;
import com.adobe.cq.sightly.WCMUsePojo;
import com.infield.magento.core.MagentoCommerceSessionImpl;
import org.apache.sling.api.request.RequestParameter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;


/**
 * Supports order completion page
 *
 * This component is to support the demo and clearing the number of items in the cart after
 * checkout. Current we.retail interfaces and components don't allow for changing or modifying
 * of cart contents on frontend so this can also be used to manually reset the state of the
 * cart.
 */
public class ThankYou extends WCMUsePojo {

    private String order;

    private static final String PARAMETER_ORDER_ID = "order";
    private static final Logger log = LoggerFactory.getLogger(ThankYou.class);

    @Override public void activate() throws Exception {
        CommerceService service = this.getResource().adaptTo(CommerceService.class);
        MagentoCommerceSessionImpl session = (MagentoCommerceSessionImpl)service.login(this.getRequest(), this.getResponse());
        List<CommerceSession.CartEntry> entries = session.getCartEntries();
        int size = entries.size();
        try{
            session.clearCommerceState();
        }catch (CommerceException e){
            log.error("Unable to clear commerce state in order complete component.");
        }

        //If there are items in the cart, we will delete them and then refresh the page
        //to make sure the other components have the correct state
        if(size > 0){
            session.clearCommerceState();
            String path = this.getRequest().getPathInfo();
            String queryString = this.getRequest().getQueryString();
            getResponse().sendRedirect(path + "?" + queryString);
        }

        //Get the order increment ID from the query string
        RequestParameter requestOrderId = this.getRequest().getRequestParameter(PARAMETER_ORDER_ID);
        if(requestOrderId != null){
            order = requestOrderId.toString();
        }
        else{
            this.order = null;
        }

    }

    public String getOrder(){
        return this.order;
    }
}
