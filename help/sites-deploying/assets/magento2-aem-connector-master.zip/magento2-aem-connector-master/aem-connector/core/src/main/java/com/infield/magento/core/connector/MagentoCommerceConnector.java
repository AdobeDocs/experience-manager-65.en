package com.infield.magento.core.connector;

import com.adobe.cq.commerce.api.CommerceException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infield.magento.catalog.connector.models.MagentoProduct;
import com.infield.magento.core.connector.model.*;
import com.infield.magento.identity.models.AuthCredentials;
import com.infield.magento.identity.models.MagentoCustomer;

import org.apache.felix.scr.annotations.*;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.apache.jackrabbit.oak.spi.security.ConfigurationParameters;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


@Component(
        label = "Magento 2 Commerce Provider",
        configurationFactory = true,
        metatype = true,
        policy = ConfigurationPolicy.REQUIRE
)
@Service(MagentoCommerceConnector.class)
@Properties(value = {
    @Property(name = "service.description", value = "Magento 2 Commerce Provider"),
    @Property(name = "service.vendor", value = "Infield Digital"),
})
public class MagentoCommerceConnector {

    private static String colorCode;
    private static String sizeCode;
    private static final Logger log = LoggerFactory.getLogger(MagentoCommerceConnector.class);

    private ObjectMapper mapper = new ObjectMapper();

    private static String server = "http://localhost:8000";

    @Property(
            name = "SERVER",
            label = "Magento Server",
            description = "Magento Server",
            value = ""
    )
    public static final String SERVER = "SERVER";


    public MagentoCommerceConnector() {
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
    }


    @SuppressWarnings("UnusedDeclaration")
    @Activate
    private void activate(Map<String, Object> properties) {

        ConfigurationParameters cfg = ConfigurationParameters.of(properties);
        server = cfg.getConfigValue(SERVER, "http://localhost:8000");

        try {
            this.colorCode = getAttributeID("color");
            this.sizeCode = getAttributeID("size");
        } catch (Exception e) {
            log.error("Error Setting Attributes!" + e);
            e.printStackTrace();
        }
    }


    public static String getServer() {
        return server;
    }

    public static void setServer(String server) {
        MagentoCommerceConnector.server = server;
    }

    public String getToken(String username, String password)throws Exception{
        AuthCredentials authCredentials = new AuthCredentials(username, password);

        log.debug(" AUTHENTICATING " + username + " Against server:" + server);
        String token = Request.Post(server + "/rest/V1/integration/customer/token")
                .bodyString(mapper.writeValueAsString(authCredentials), ContentType.APPLICATION_JSON)
                .execute().returnContent().asString();
        return "Bearer " + token.replace("\"", "");

    }



    public String initCart(String authToken) throws Exception {
        String predicate = (authToken == null) ?  "guest-carts/" : "carts/mine";

        String cartId = Request.Post(server + "/rest/V1/" + predicate)
                .addHeader("Authorization", authToken)
                .bodyString("{}", ContentType.APPLICATION_JSON)
                .execute().returnContent().asString();
        return cartId.replace("\"", "");
    }


    public String addItemToCart(String cartId, String authToken, MagentoCartItem item){

        log.debug("Adding Item to Cart " + item.cartItem.sku + " to Cart :" + item.cartItem.quote_id);
        log.debug("Auth Token " + authToken);

        String predicate = (authToken == null) ?  "guest-carts/" : "carts/";

        cartId = (authToken == null) ?  cartId : "mine";
        try {
            log.debug("JSON body:" + mapper.writeValueAsString(item));

            Request request = Request.Post(server + "/rest/V1/" + predicate + cartId +"/items");
            if(authToken != null){
                request.addHeader("Authorization", authToken);
            }
            return request.bodyString(mapper.writeValueAsString(item), ContentType.APPLICATION_JSON)
                    .execute().handleResponse(new ResponseHandler<String>() {

                       public String handleResponse(final HttpResponse response) throws IOException {
                           StatusLine statusLine = response.getStatusLine();
                           HttpEntity entity = response.getEntity();
                           if (statusLine.getStatusCode() >= 300) {
                               HashMap returnValues = mapper.readValue(entity.getContent(), HashMap.class);
                               String message = substituteParameters(returnValues);
                               log.debug("ERROR:" + message);
                               throw new HttpResponseException(
                                       statusLine.getStatusCode(),message);
                           }
                           if (entity == null) {
                               throw new ClientProtocolException("Response contains no content");
                           }
                           HashMap item =  mapper.readValue(entity.getContent(), HashMap.class);
                           return item.get("price") + "";
                       }

                   });
        } catch (IOException e) {
            log.error("Unable to add " + item.cartItem.sku + " to Cart :" + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    private String substituteParameters(HashMap returnValues) {
        String message = (String)returnValues.get("message");
        LinkedHashMap parameters = (LinkedHashMap)returnValues.get("parameters");
        if (parameters != null) {
            message.replaceAll("%fieldName", (String)parameters.get("fieldName"));
            message.replaceAll("%fieldValue", (String)parameters.get("fieldValue"));
        }
        return message;
    }



    public String addConfigurableItemToCart(String cartId, String authToken, String sku, int quantity, String color, String size){


        String requestString = "";
        try {

            if(this.colorCode == null || this.sizeCode == null){
                this.colorCode = getAttributeID("color");
                this.sizeCode = getAttributeID("size");
            }

            JSONObject cartItem = new JSONObject();
            cartItem.put("quote_id", cartId);
            cartItem.put("sku", sku);
            cartItem.put("qty", quantity);
            cartItem.put("product_type", "configurable");

            JSONArray configurationArray = new JSONArray();


            if (color != null) {
                JSONObject colorConfiguration = new JSONObject();
                colorConfiguration.put("option_id", Integer.parseInt(this.colorCode));
                colorConfiguration.put("option_value", Integer.parseInt(color));
                configurationArray.put(colorConfiguration);
            }

            if (size != null) {
                JSONObject sizeConfiguration = new JSONObject();
                sizeConfiguration.put("option_id", Integer.parseInt(this.sizeCode));
                sizeConfiguration.put("option_value", Integer.parseInt(size));
                configurationArray.put(sizeConfiguration);
            }


            JSONObject configurable_item_options = new JSONObject().put("configurable_item_options", configurationArray);

            JSONObject extension_attributes = new JSONObject().put("extension_attributes", configurable_item_options);
            cartItem.put("product_option",extension_attributes);

            JSONObject envelop = new JSONObject();
            envelop.put("cartItem", cartItem);
            requestString = envelop.toString();

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (CommerceException e) {
            log.error("ERROR GETTING COLOR OR SIZE CODE" + e);
        }


        String predicate = (authToken == null) ?  "guest-carts/" : "carts/";
        cartId = (authToken == null) ?  cartId : "mine";

        try {
            return Request.Post(server + "/rest/V1/" + predicate + cartId +"/items")
                    .addHeader("Authorization", authToken)
                    .bodyString(requestString, ContentType.APPLICATION_JSON)
                    .execute().handleResponse(new ResponseHandler<String>() {

                        public String handleResponse(final HttpResponse response) throws IOException {
                            StatusLine statusLine = response.getStatusLine();
                            HttpEntity entity = response.getEntity();
                            if (statusLine.getStatusCode() >= 300) {
                                HashMap returnValues = mapper.readValue(entity.getContent(), HashMap.class);

                                String message = (String)returnValues.get("message");
                                log.error("ERROR:" + message);
                                throw new HttpResponseException(
                                        statusLine.getStatusCode(),(String)message);
                            }
                            if (entity == null) {
                                throw new ClientProtocolException("Response contains no content");
                            }
                            HashMap item =  mapper.readValue(entity.getContent(), HashMap.class);
                            return item.get("price") + "";
                        }

                    });
        } catch (IOException e) {
            log.error("Unable to add to Cart :" + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }


    public void removeItemFromCart(String cartId, String authToken, String sku)throws Exception{
        String predicate = (authToken == null) ?  "guest-carts/" : "carts/";
             //todo: We don't currently have an item_id, only the item
            String response =  Request.Delete(server + "rest/V1/" + predicate + cartId +"/items/{itemId}")
                    .addHeader("Authorization", authToken)
                    .execute().returnContent().asString();
    }

    public List<MagentoShippingCarrier> getShippingOptions(String cartId, String authToken, String countryCode, String postalCode) throws IOException {

        String predicate = (authToken == null) ?  "guest-carts/" : "carts/";

        cartId = (authToken == null)? cartId : "mine";

        String json = "{\n" +
                "  \"address\": {\n" +
                "    \"countryId\": \"" + countryCode + "\",\n" +
                "    \"postcode\": \"" + postalCode + "\"\n" +
                "  }\n" +
                "}";
        String carrierString = Request.Post(server + "/rest/V1/" + predicate + cartId +"/estimate-shipping-methods")
                .addHeader("Authorization", authToken)
                .bodyString(json, ContentType.APPLICATION_JSON)
                .execute().returnContent().asString();
        return  mapper.readValue(carrierString, new TypeReference<List<MagentoShippingCarrier>>(){});
    }

    public String setShippingInfo(String cartId, String authToken, MagentoShippingInfo shippingInfo) throws IOException {

        String predicate = (authToken == null) ?  "guest-carts/" : "carts/";

        cartId = (authToken == null) ? cartId : "mine";

        log.debug("Calling shipping-information");
        String response = Request.Post(server + "/rest/V1/" + predicate + cartId +"/shipping-information")
                .addHeader("Authorization", authToken)
                .bodyString(mapper.writeValueAsString(shippingInfo), ContentType.APPLICATION_JSON)
                .execute().returnContent().asString();
        log.debug("Response for shipping-information:" + response);
        return response;
    }

    private void writeShippingResponseToCookie(MagentoShippingResponse shippingResponse) {

    }

    public void setPaymentInfo(String cartId, String authToken, MagentoPaymentInfo paymentInfo) throws Exception {
        String predicate = (authToken == null) ?  "guest-carts/" : "carts/";

        cartId = (authToken == null) ? cartId : "mine";

        try {
            String response = Request.Post(server + "/rest/V1/" + predicate + cartId +"/set-payment-information")
                    .addHeader("Authorization", authToken)
                    .bodyString(mapper.writeValueAsString(paymentInfo), ContentType.APPLICATION_JSON)
                    .execute().returnContent().asString();
            log.debug("Response for add Payment info to cart: " + response);
        } catch (IOException e) {
            log.error("Unable to add Payment Info :" + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }


    public String createOrder(String cartId, String authToken) throws Exception {
        String predicate = (authToken == null) ?  "guest-carts/" : "carts/";

        cartId = (authToken == null) ? cartId : "mine";

         return  Request.Put(server + "/rest/V1/" + predicate + cartId +"/order")
                    .addHeader("Authorization", authToken)
                    .bodyString("{}", ContentType.APPLICATION_JSON)
                    .execute().handleResponse(new ResponseHandler<String>() {

                        public String handleResponse(final HttpResponse response) throws IOException {
                            StatusLine statusLine = response.getStatusLine();
                            HttpEntity entity = response.getEntity();
                            if (statusLine.getStatusCode() >= 300) {
                                HashMap returnValues = mapper.readValue(entity.getContent(), HashMap.class);

                                String message = (String)returnValues.get("message");
                                throw new HttpResponseException(
                                        statusLine.getStatusCode(),message);
                            }
                            if (entity == null) {
                                throw new ClientProtocolException("Response contains no content");
                            }
                            return mapper.readValue(entity.getContent(), String.class);
                        }

                    });
    }

    public void associateCartWithCustomer(String cartId, Long userId, Long storeId, String authToken) throws CommerceException{
        String json = "{\n" +
                "    \"customerId\": \"" + userId + "\",\n" +
                "    \"storeId\": \"" + storeId + "\"\n" +
                "}";
        try {
            String responseString = Request.Put(server + "/rest/V1/guest-carts/" + cartId)
                    .addHeader("Authorization", authToken)
                    .bodyString(json, ContentType.APPLICATION_JSON)
                    .execute().handleResponse(new ResponseHandler<String>() {

                        public String handleResponse(final HttpResponse response) throws IOException {
                            StatusLine statusLine = response.getStatusLine();
                            HttpEntity entity = response.getEntity();
                            if (statusLine.getStatusCode() >= 300) {
                                HashMap returnValues = mapper.readValue(entity.getContent(), HashMap.class);

                                List message = (List)returnValues.get("parameters");
                                throw new HttpResponseException(
                                        statusLine.getStatusCode(),(String)message.get(0));
                            }
                            if (entity == null) {
                                throw new ClientProtocolException("Response contains no content");
                            }
                            return mapper.readValue(entity.getContent(), String.class);
                        }

                    });
        } catch (HttpResponseException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public MagentoCustomer getCustomer(String authToken) throws CommerceException{
        try {
            String response = Request.Get(server  +"/rest/V1/customers/me")
                    .addHeader("Authorization", authToken)
                    .execute().returnContent().asString();
            return mapper.readValue(response, MagentoCustomer.class);
        } catch (IOException e) {
            throw new CommerceException(e.getMessage());
        }

    }


    public MagentoProduct getProduct(String authToken, String sku) throws CommerceException {
        try {
            String response = Request.Get(server+"/rest/V1/products/" + sku)
                        .addHeader("Authorization", authToken)
                        .execute().returnContent().asString();
            return mapper.readValue(response, MagentoProduct.class);
        } catch (IOException e) {
            throw new CommerceException(e.getMessage());
        }
    }



    public String getAttributeID(String attributeName) throws CommerceException {

        try {
            String response = Request.Get(server+"/rest/V1/products/attributes/" + attributeName)
                    .execute().returnContent().asString();

            HashMap results = mapper.readValue(response, HashMap.class);
            return results.get("attribute_id").toString();
        } catch (IOException e) {
            throw new CommerceException(e.getMessage());
        }
    }


}
