package com.infield.magento.core;

import com.adobe.cq.commerce.api.*;
import com.adobe.cq.commerce.api.promotion.PromotionInfo;
import com.adobe.cq.commerce.api.promotion.VoucherInfo;
import com.adobe.cq.commerce.common.AbstractJcrCommerceService;
import com.adobe.cq.commerce.common.AbstractJcrCommerceSession;
import com.adobe.cq.commerce.common.DefaultJcrCartEntry;
import com.adobe.cq.commerce.common.PriceFilter;
import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.i18n.I18n;
import com.day.cq.personalization.ContextSessionPersistence;
import com.infield.magento.catalog.connector.models.MagentoProduct;
import com.infield.magento.core.connector.MagentoCommerceConnector;
import com.infield.magento.core.connector.model.*;
import com.infield.magento.core.util.USStateUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.jackrabbit.util.Text;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.commons.collections.Predicate;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

import javax.jcr.*;
import javax.jcr.query.Query;
import java.io.IOException;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.util.*;

public class MagentoCommerceSessionImpl extends AbstractJcrCommerceSession {

    private MagentoCommerceConnector connector = new MagentoCommerceConnector();
    private String cartId;
    private String magentoToken;

    public MagentoCommerceSessionImpl(AbstractJcrCommerceService commerceService,
                                      SlingHttpServletRequest request,
                                      SlingHttpServletResponse response,
                                      Resource resource) throws CommerceException {
        super(commerceService, request, response, resource);
        PN_UNIT_PRICE = MagentoProductImpl.PN_PRICE;
    }


    public void setMagentoToken(String magentoToken) {
        this.magentoToken = magentoToken;
    }

    /**
     * Clear out the contents of the cart and related order details
     *
     * @throws CommerceException
     */
    public void clearCommerceState() throws CommerceException{
        this.cart.clear();
        this.cartId = null;
        this.vouchers.clear();
        this.orderDetails.clear();
        this.saveCart();
        ContextSessionPersistence.put(this.request, this.response, "magento-cartId", "");
        this.initCart();
    }

    @Override
    protected BigDecimal getShipping(String method) {

        BigDecimal amount = BigDecimal.ZERO;
        HashMap<String, String> magentoShippingOptions = getMagentoShippingOptions();

        try {
            List<ShippingMethod> shippingMethods = this.getAvailableShippingMethods();

            for(ShippingMethod shippingMethod: shippingMethods){
                if(shippingMethod.getPath().equalsIgnoreCase(method)){
                    String price = magentoShippingOptions.get(shippingMethod.getProperty("carrier", String.class) + ":" + shippingMethod.getProperty("method", String.class));
                    if(price != null){
                        amount =  BigDecimal.valueOf(Double.parseDouble(price));
                    }
                }
            }

        } catch (CommerceException e) {
            e.printStackTrace();
        }
        return amount;
    }

    @Override
    protected String tokenizePaymentInfo(Map<String, String> paymentDetails) throws CommerceException {
        //
        // This is only a stub implementation for the Geometrixx-Outdoors demo site, for which there is no
        // real payment processing (or payment info tokenization).
        //
        return "faux-payment-token";
    }


    protected void writeOrder(Node orderNode, Calendar placedTime, Session session) throws CommerceException, RepositoryException {
        ArrayList lineItems = new ArrayList();
        Iterator itemsIterator = this.cart.iterator();

        while(itemsIterator.hasNext()) {
            CartEntry cartEntry = (CartEntry)itemsIterator.next();
            lineItems.add(cartEntry.getProduct().getSKU() + ":" + cartEntry.getQuantity());
        }

        orderNode.setProperty("lineItems", (String[])lineItems.toArray(new String[lineItems.size()]));
        super.writeOrder(orderNode, placedTime, session);
    }

    @Override
    public void addCartEntry(Product product, int quantity) throws CommerceException {
        String color = product.getProperty("colorCode", String.class);
        String size = product.getProperty("sizeCode", String.class);

        log.debug("adding Product in Cart- SKU:" + product.getSKU() + " / QTY:" + quantity + "  COlor:" + color + " SIZE:" + size);

        if(size != null || color != null){
            String baseSku = product.getProperty("baseSku", String.class);
            String price = connector.addConfigurableItemToCart(cartId, magentoToken, baseSku, quantity, color, size);
            super.addCartEntry(product, quantity);
        } else {
            MagentoCartItem cartItem = new MagentoCartItem(new MagentoCartItem.CartItem(product.getSKU(), quantity, cartId));
            try {
                String price = connector.addItemToCart(cartId, magentoToken, cartItem);
                super.addCartEntry(product, quantity);
                log.error("Added Product in Cart- SKU:" + product.getSKU() + " / QTY:" + quantity + " Price point:" + price);
            } catch (Exception addToCartException) {
                log.error("unable to add Product in Cart - SKU:" + product.getSKU() + " / QTY:" + quantity);
                log.error("Error:" + addToCartException.toString());
                throw new CommerceException(addToCartException.getMessage(),addToCartException);
            }
        }
    }




    @Override
    public void deleteCartEntry(int entryNumber) throws CommerceException {

        if(entryNumber < this.cart.size()) {
            try{
                CartEntry entry =  cart.get(entryNumber);
                String sku = entry.getProduct().getSKU();
                //connector.removeItemFromCart(magentoToken, sku);
                super.deleteCartEntry(entryNumber);
            }catch (Exception deleteFromCartException){
                log.error("unable to Delete Product from Cart - Entry Number:"  + entryNumber);
            }

        }

    }

    protected void doUpdateOrderDetails(Map<String, String> delta) throws CommerceException {

       if (delta.containsKey("payment-option")) {
            try {
                String state = delta.get("billing.state");

                if(state.length() > 2){
                    USStateUtil states = new USStateUtil();
                    state = states.getStateCode(state);
                }

                String country = delta.get("billing.country");
                String street1 = delta.get("billing.street1");
                String[] streets = {street1};
                String postal = delta.get("billing.zip");
                String city = delta.get("billing.city");
                String firstName = delta.get("billing.firstname");
                String lastName = delta.get("billing.lastname");
                String phone = "801-555-1234"; //No Phone in Geometrixx
                String paymentOption = delta.get("payment-option");
                MagentoAddress address = new MagentoAddress(state, country, streets, phone, postal, city, firstName, lastName);
                Node node = resolver.getResource(paymentOption).adaptTo(Node.class);
                String predicate = node.getNode("jcr:content").getProperty("predicate").getString();
                /*
                    The api call says that it can take additional data. From the geometrixx impl we get
                    a bunch of keys in the delta map that start with 'payment.', for example "payment.cardType='visa'"
                    Going to leave this out for now because we're not focusing on this yet, but it could look something like this

                HashMap<String,String> additionalData = new HashMap<>();
                Iterator keys = delta.keySet().iterator();
                while (keys.hasNext()) {
                    String key = (String)keys.next();
                    if (key.startsWith("payment.")) {
                        String value = delta.get(key);
                        additionalData.put(key,value);
                    }
                }
                String [] addDataArr = new String[]{};
                MagentoPaymentInfo paymentInfo = new MagentoPaymentInfo(new MagentoPaymentInfo.PaymentMethod(predicate, addDataArr), address);
                */
                MagentoPaymentInfo paymentInfo = new MagentoPaymentInfo(new MagentoPaymentInfo.PaymentMethod(predicate), address);
                log.debug("Adding Payment Info");
                connector.setPaymentInfo(cartId, magentoToken, paymentInfo);

            } catch (Exception e) {
                throw new CommerceException(e.getMessage());
            }

        } else if (delta.containsKey("shipping-option")) {
            try {
                String shippingOption = delta.get("shipping-option");
                log.debug("Set Shipping Option!!! : " + shippingOption);
            } catch (Exception e) {
                throw new CommerceException(e.getMessage());
            }
        } else if (delta.containsKey("shipping.state") &&
               delta.containsKey("shipping.country") &&
               delta.containsKey("shipping.street1") &&
               delta.containsKey("shipping.lastname")) {

            try {

                String shippingState = delta.get("shipping.state");

                if(shippingState.length() > 2){
                    USStateUtil states = new USStateUtil();
                    shippingState = states.getStateCode(shippingState);
                }


                String shippingCountry = delta.get("shipping.country");
                String street1 = delta.get("shipping.street1");
                String[] streets = {street1};
                String shippingPostal = delta.get("shipping.zip");
                String shippingCity = delta.get("shipping.city");
                String shippingFirstName = delta.get("shipping.firstname");
                String shippingLastName = delta.get("shipping.lastname");
                String shippingPhone = "801-555-1234"; //No Phone in Geometrixx


                //start off by getting the shipping options for this address

                List<MagentoShippingCarrier> carriers = connector.getShippingOptions(cartId, magentoToken,shippingCountry, shippingPostal);
                StringBuffer carriersString = new StringBuffer();

                for (MagentoShippingCarrier carrier: carriers) {
                    carriersString.append(carrier.carrier_code + ":" + carrier.method_code + "/" + carrier.amount);
                    carriersString.append("|");
                }

                //save these shipping options ot the cookie
                ContextSessionPersistence.put(this.request, this.response, "shippingOptions", carriersString.toString());
                MagentoAddress address = new MagentoAddress(shippingState, shippingCountry, streets, shippingPhone, shippingPostal, shippingCity, shippingFirstName, shippingLastName);
                MagentoShippingInfo shippingInfo = new MagentoShippingInfo(new MagentoShippingInfo.AddressInformation(address, "flatrate", "flatrate"));

                String shippingResponse = connector.setShippingInfo(cartId, magentoToken, shippingInfo);
                ContextSessionPersistence.put(this.request, this.response, "shippingResponse", shippingResponse);
            } catch (Exception e) {
                throw new CommerceException(e.getMessage());
            }
        }
        super.doUpdateOrderDetails(delta);
    }


    @Override
    protected void initiateOrderProcessing(String orderPath) throws CommerceException {

        Session serviceSession = null;
        try {
            serviceSession = commerceService.serviceContext().slingRepository.loginService("orders", null);

            log.debug("Processing Order");
            Node order = serviceSession.getNode(orderPath);
            String orderId = connector.createOrder(cartId, magentoToken);
            order.setProperty("orderStatus", "Created (Magento Reference ID:" + orderId + ")");
            order.setProperty("magentoOrderId", orderId);
            order.getSession().save();
            ContextSessionPersistence.put(request, response, "magento-cartId", ""); // need to clear this because the cartId changes, I think
        } catch (Exception e) {
            log.error("Failed to create order in Magento:" + e);
            log.error("Failed to update order", e);
            throw new CommerceException(e.getMessage(), e);
        } finally {
            if (serviceSession != null) {
                serviceSession.logout();
            }
        }

    }


    @Override
    protected String getOrderStatus(String orderId) throws CommerceException {
        //
        // Status is kept in the vendor section (/etc/commerce); need to find corresponding order there.
        //
        Session serviceSession = null;
        try {
            serviceSession = commerceService.serviceContext().slingRepository.loginService("orders", null);
            //
            // example query: /jcr:root/etc/commerce/orders//element(*)[@orderId='foo')]
            //
            StringBuilder buffer = new StringBuilder();
            buffer.append("/jcr:root/etc/commerce/orders//element(*)[@orderId = '")
                    .append(Text.escapeIllegalXpathSearchChars(orderId).replaceAll("'", "''"))
                    .append("']");

            final Query query = serviceSession.getWorkspace().getQueryManager().createQuery(buffer.toString(), Query.XPATH);
            NodeIterator nodeIterator = query.execute().getNodes();
            if (nodeIterator.hasNext()) {
                return nodeIterator.nextNode().getProperty("orderStatus").getString();
            }
        } catch (Exception e) {
            // fail-safe when the query above contains errors
            log.error("Error while fetching order status for orderId '" + orderId + "'", e);
        } finally {
            if (serviceSession != null) {
                serviceSession.logout();
            }
        }
        final I18n i18n = new I18n(request);
        return i18n.get("unknown", "order status");
    }

    @Override
    protected Predicate getPredicate(String predicateName) {
        //
        // This stub implementation supports only the openOrders predicate.
        //
        if (predicateName != null && predicateName.equals(CommerceConstants.OPEN_ORDERS_PREDICATE)) {
            return new Predicate() {
                public boolean evaluate(Object object) {
                    try {
                        PlacedOrder order = (PlacedOrder) object;
                        String status = (String) order.getOrder().get("orderStatus");
                        return (status != null && !status.equals("Completed") && !status.equals("Cancelled"));
                    } catch (CommerceException e) {
                        return false;
                    }
                }
            };
        }
        return null;
    }


    @Override
    public List<ShippingMethod> getAvailableShippingMethods() throws CommerceException {

        List<ShippingMethod> shippingMethods = super.getAvailableShippingMethods(); // from jcr
        ArrayList<ShippingMethod> filteredShippingMethods = new ArrayList<ShippingMethod>();

        HashMap<String, String> magentoShippingOptions = getMagentoShippingOptions();

        if(!magentoShippingOptions.isEmpty()){
            for(ShippingMethod shippingMethod: shippingMethods){
                String carrier = shippingMethod.getProperty("carrier", String.class);
                String method = shippingMethod.getProperty("method", String.class);
                if(magentoShippingOptions.containsKey(carrier + ":" + method)){
                    filteredShippingMethods.add(shippingMethod);
                }
            }
            shippingMethods = filteredShippingMethods;
        }
        return shippingMethods;
    }

    public List<PaymentMethod> getAvailablePaymentMethods() throws CommerceException {
        log.debug("Called getAvailable paymemtn methods!");
        List<PaymentMethod> jcrPaymentMethods = commerceService.getAvailablePaymentMethods(); // from jcr
        List<PaymentMethod> rv = new ArrayList<PaymentMethod>();
        HashMap<String,String> magentoMethods = getMagentoPaymentMethods();
        for (PaymentMethod jcrMethod: jcrPaymentMethods) {
            String predicate = jcrMethod.getPredicate();
            log.debug("predicate:"+predicate);
            if (predicate != null && magentoMethods.containsKey(predicate)) {
                rv.add(jcrMethod);
            } else {
                log.error("didnt find:"+predicate+" in map");
            }
        }
        return rv;
    }

    /**
     * @todo What if the cartId changes? Shouldn't we at least try to get it from the service once and then write it to the cookie?
     * @throws CommerceException
     */
    public void initCart() throws CommerceException {
        if (this.cartId == null || this.cartId.length() < 1) {
            log.debug(" START of Init cart no cartID");

            this.cartId = ContextSessionPersistence.get(this.request, "magento-cartId");
            log.debug("cartID from cookie is " + cartId);

            if(cartId == null || this.cartId.length() < 1){
                // no cart ID in Cookie looks like we need to initalize one.
                // If I have a magentoToken then we will create on for that Customer is not we will Create on for a guest.
                try{

                    this.cartId = connector.initCart(magentoToken);

                    log.debug("tried to get Cart ID using magentoToken " + magentoToken+" cartId:"+cartId);

                  /*  for(CartEntry entry: cart){
                        MagentoCartItem cartItem = new MagentoCartItem(new MagentoCartItem.CartItem(entry.getProduct().getSKU(), entry.getQuantity(), this.cartId));
                        connector.addItemToCart(this.cartId, magentoToken, cartItem);
                    }*/
                    ContextSessionPersistence.put(this.request, this.response, "magento-cartId", this.cartId);
                } catch (Exception e) {
                    throw new CommerceException(e.getMessage());
                }
            }
        }

    }

    private HashMap getMagentoShippingOptions(){

        HashMap<String, String> returnOptions = new HashMap<String, String>();
        String shippingOptions = ContextSessionPersistence.get(this.request, "shippingOptions");

        if(shippingOptions != null && shippingOptions.length() > 0){
            String[] options = shippingOptions.split("\\|");
            for(String option:options){
                String[] optionDetails = option.split("/");
                returnOptions.put(optionDetails[0], optionDetails[1]);
            }
        }
        return returnOptions;
    }

    private HashMap getMagentoPaymentMethods() {
        HashMap<String, String> returnOptions = new HashMap<String, String>();
        String shippingResponse = ContextSessionPersistence.get(this.request, "shippingResponse");
        try {
            JSONObject json = new JSONObject(shippingResponse);
            JSONArray methods = json.getJSONArray("payment_methods");
            int length = methods.length();
            for (int i=0; i < length; i++) {
                JSONObject method = methods.getJSONObject(i);
                returnOptions.put(method.getString("code"), method.getString("title"));
            }

        } catch (JSONException jsone) {
            log.error("Error parsing json for shippingResponse");
        }
        return returnOptions;
    }

}
