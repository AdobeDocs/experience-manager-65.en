package com.infield.magento.catalog.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class MagentoProduct {

    public final long id;
    public final String sku;
    public final String name;
    public final long attribute_set_id;
    public final BigDecimal price;
    public final long status;
    public final long visibility;
    public final String type_id;
    public final String created_at;
    public final String updated_at;
    public final Product_link product_links[];
    public final Option options[];
    public final Tier_price tier_prices[];
    public final Custom_attribute custom_attributes[];
    public final Media_gallery_entry media_gallery_entries[];
    public List<String> categoryIds;


        public String toString(){
            return "SKU:" + this.sku + ", Name:" + this.name;
        }

        public HashMap<String, String> getBaseAttributes(){
            HashMap map = new HashMap();

            map.put("sku", sku);
            map.put("status", status);
            map.put("price", price);
            map.put("visibility", visibility);
            map.put("description", this.getAttribute("description"));
            map.put("image", this.getAttribute("image"));
            return map;

        }

        public HashMap<String, String> getCustomAttributes(){
            HashMap<String, String> attributesMap = new HashMap<String, String>();
            for(Custom_attribute custom_attribute: this.custom_attributes){
                attributesMap.put(custom_attribute.attribute_code, custom_attribute.value[0]);
            }
            return attributesMap;
        }


        public String getAttribute(String name){

            String value = null;
            for(Custom_attribute attribute: this.custom_attributes){
                if(attribute.attribute_code.equalsIgnoreCase(name)){
                    if(attribute.value.length < 2){
                        value = attribute.value[0];
                    }else{
                        String returnValue = "";
                        for(String s: attribute.value){
                            returnValue = s + " ";
                        }
                        value = returnValue;
                    }
                    break;
                }
            }
            return value;
        }


        public boolean hasImage(){

            return this.getAttribute("image").length() > 0 || this.media_gallery_entries.length > 0;
        }

        public String getPrimaryImagePath(){
            //todo: this needs to be decided on - should we always use the media_gallery_entries if they exist?
            if(this.media_gallery_entries.length > 0){
                return this.media_gallery_entries[0].file;
            }
            else if(this.getAttribute("image").length() > 0){
                return this.getAttribute("image");
            }
            else{
                return null;
            }
        }


        @JsonCreator
        public MagentoProduct(@JsonProperty("id") long id, @JsonProperty("sku") String sku, @JsonProperty("name") String name, @JsonProperty("attribute_set_id") long attribute_set_id, @JsonProperty("price") String price, @JsonProperty("status") long status, @JsonProperty("visibility") long visibility, @JsonProperty("type_id") String type_id, @JsonProperty("created_at") String created_at, @JsonProperty("updated_at") String updated_at, @JsonProperty("product_links") Product_link[] product_links, @JsonProperty("options") Option[] options, @JsonProperty("tier_prices") Tier_price[] tier_prices, @JsonProperty("custom_attributes") Custom_attribute[] custom_attributes, @JsonProperty("media_gallery_entries") Media_gallery_entry[] media_gallery_entries){
            this.id = id;
            this.sku = sku;
            this.name = name;
            this.attribute_set_id = attribute_set_id;
            this.price = new BigDecimal(price);
            this.status = status;
            this.visibility = visibility;
            this.type_id = type_id;
            this.created_at = created_at;
            this.updated_at = updated_at;
            this.product_links = product_links;
            this.options = options;
            this.tier_prices = tier_prices;
            this.custom_attributes = custom_attributes;
            this.media_gallery_entries = media_gallery_entries;
        }

    @JsonIgnoreProperties(ignoreUnknown = true)
        public static final class Product_link {
            public final String sku;
            public final String link_type;
            public final String linked_product_sku;
            public final String linked_product_type;
            public final Extension_attribute extension_attributes[];

            @JsonCreator
            public Product_link(@JsonProperty("sku") String sku, @JsonProperty("link_type") String link_type, @JsonProperty("linked_product_sku") String linked_product_sku, @JsonProperty("linked_product_type") String linked_product_type, @JsonProperty("extension_attributes") Extension_attribute[] extension_attributes){
                this.sku = sku;
                this.link_type = link_type;
                this.linked_product_sku = linked_product_sku;
                this.linked_product_type = linked_product_type;
                this.extension_attributes = extension_attributes;
            }

        @JsonIgnoreProperties(ignoreUnknown = true)
            public static final class Extension_attribute {

                @JsonCreator
                public Extension_attribute(){
                }
            }
        }

    @JsonIgnoreProperties(ignoreUnknown = true)
        public static final class Option {

            @JsonCreator
            public Option(){
            }
        }

    @JsonIgnoreProperties(ignoreUnknown = true)
        public static final class Tier_price {

            @JsonCreator
            public Tier_price(){
            }
        }

    @JsonIgnoreProperties(ignoreUnknown = true)
        public static final class Custom_attribute {
            public final String attribute_code;
            public final String[] value;

            @JsonCreator
            public Custom_attribute(@JsonProperty("attribute_code") String attribute_code, @JsonProperty("value") String[] value){
                this.attribute_code = attribute_code;
                this.value = value;
            }
        }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Media_gallery_entry {
        public final int id;
        public final String media_type;
        public final String label;
        public final int position;
        public final boolean disabled;
        public final String types[];
        public final String file;

        @JsonCreator
        public Media_gallery_entry(@JsonProperty("id") int id,
                                    @JsonProperty("media_type") String media_type,
                                    @JsonProperty("file") String file,
                                    @JsonProperty("label") String label,
                                    @JsonProperty("position") int position,
                                    @JsonProperty("disabled") boolean disabled,
                                    @JsonProperty("types") String[] types){
            this.id = id;
            this.media_type = media_type;
            this.label = label;
            this.position = position;
            this.file = file;
            this.disabled = disabled;
            this.types = types;

        }
    }

    public String getAttributeId(String attibuteCode){
        for(Custom_attribute attribute: custom_attributes){
            if(attribute.attribute_code.equalsIgnoreCase(attibuteCode)) {
                String value;
                if(attribute.value.length > 1){
                    value = attribute.value[0];
                }else{

                    StringBuilder nameBuilder = new StringBuilder();
                    for (String n : attribute.value) {
                        nameBuilder.append(n).append(",");
                    }
                    nameBuilder.deleteCharAt(nameBuilder.length() - 1);
                    value = nameBuilder.toString();
                }
                return value;
            }
        }
        return null;
    }

    public void setCategoryIds(List<String> categoryIds) {
        this.categoryIds = categoryIds;
    }
}
