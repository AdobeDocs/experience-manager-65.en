package com.infield.magento.core.connector.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class MagentoShippingCarrier {
    public final String carrier_code;
    public final String method_code;
    public final String carrier_title;
    public final String method_title;
    public final double amount;
    public final double base_amount;
    public final boolean available;
    public final String error_message;
    public final double price_excl_tax;
    public final double price_incl_tax;

    @JsonCreator
    public MagentoShippingCarrier(@JsonProperty("carrier_code") String carrier_code, @JsonProperty("method_code") String method_code, @JsonProperty("carrier_title") String carrier_title, @JsonProperty("method_title") String method_title, @JsonProperty("amount") double amount, @JsonProperty("base_amount") double base_amount, @JsonProperty("available") boolean available, @JsonProperty("error_message") String error_message, @JsonProperty("price_excl_tax") double price_excl_tax, @JsonProperty("price_incl_tax") double price_incl_tax){
        this.carrier_code = carrier_code;
        this.method_code = method_code;
        this.carrier_title = carrier_title;
        this.method_title = method_title;
        this.amount = amount;
        this.base_amount = base_amount;
        this.available = available;
        this.error_message = error_message;
        this.price_excl_tax = price_excl_tax;
        this.price_incl_tax = price_incl_tax;
    }
}
