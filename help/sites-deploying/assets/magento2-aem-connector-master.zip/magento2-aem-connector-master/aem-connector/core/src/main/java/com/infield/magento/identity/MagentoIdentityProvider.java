package com.infield.magento.identity;

import com.infield.magento.identity.models.ExternalUserImpl;
import com.infield.magento.identity.models.MagentoCustomer;
import org.apache.felix.scr.annotations.*;
import org.apache.jackrabbit.oak.spi.security.ConfigurationParameters;
import org.apache.jackrabbit.oak.spi.security.authentication.external.*;

import org.apache.felix.scr.annotations.Property;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Credentials;
import javax.jcr.SimpleCredentials;
import javax.security.auth.login.LoginException;
import java.util.*;



@Service
@Component(
        label = "Magento Identity Provider",
        configurationFactory = true,
        metatype = true,
        policy = ConfigurationPolicy.REQUIRE
)
public class MagentoIdentityProvider implements ExternalIdentityProvider {

    private static final Logger log = LoggerFactory.getLogger(MagentoIdentityProvider.class);
    public static final String PN_MEMBERS = "members";
    public static final String PN_GROUPS = "groups";
    public static final String PN_PASSWORD = "password";
    private String adminUsername;
    private String adminPassword;
    private String adminToken = "";
    private static String server;
    private String name;
    MagentoIdentityConnector identityConnector = new MagentoIdentityConnector();

    /**
     * @see #getName()
     */
    public static final String PARAM_NAME_DEFAULT = "magento";

    /**
     * @see #getName()
     */
    @Property(
            label = "Provider Name",
            description = "Name of this provider configuration. This is used to reference this provider by the login modules.",
            value = PARAM_NAME_DEFAULT
    )
    public static final String PARAM_NAME = "provider.name";



    @Property(
            name = "ADMIN_USERNAME",
            label = "Admin Username",
            description = "Admin Account on Magento 2 Server",
            value = ""
    )
    public static final String ADMIN_USERNAME = "ADMIN_USERNAME";


    @Property(
            name = "ADMIN_PASSWORD",
            label = "Admin password",
            description = "Admin password on Magento 2 Server",
            value = ""
    )
    public static final String ADMIN_PASSWORD = "ADMIN_PASSWORD";



    @Property(
            name = "SERVER",
            label = "Magento 2 Server",
            description = "Magento 2 Server",
            value = ""
    )
    public static final String SERVER = "SERVER";



    @SuppressWarnings("UnusedDeclaration")
    @Activate
    private void activate(Map<String, Object> properties) {

        ConfigurationParameters cfg = ConfigurationParameters.of(properties);
        name = cfg.getConfigValue(PARAM_NAME, PARAM_NAME_DEFAULT);
        adminUsername = cfg.getConfigValue(ADMIN_USERNAME, "admin");
        adminPassword = cfg.getConfigValue(ADMIN_PASSWORD, "password123");
        server = cfg.getConfigValue(SERVER, "http://localhost:8000");
        identityConnector.setServer(server);


        try {

            log.debug("admin username:" + adminUsername);
            adminToken = identityConnector.getAdminToken(adminUsername, adminPassword);
            log.debug("Admin Token:" + adminToken);
        } catch (Exception e) {
            log.error("ERROR GETTING ADMIN TOKEN!" + e);
            e.printStackTrace();
        }

    }

    @SuppressWarnings("UnusedDeclaration")
    @Deactivate
    private void deactivate() {

    }

    public static String getServer(){
        return server;
    }

    public String getName() {
        return name;
    }

    public ExternalIdentity getIdentity( ExternalIdentityRef ref) throws ExternalIdentityException {
        return null;
    }

    public ExternalUser getUser(String userId) throws ExternalIdentityException {
        log.debug("getUSER");
        return null;
    }

    public ExternalGroup getGroup( String name) throws ExternalIdentityException {
        log.debug("GetGROUP");
        return null;
    }

    public Iterator<ExternalUser> listUsers() throws ExternalIdentityException {
        log.debug("listUSER");
        return null;
    }

    public Iterator<ExternalGroup> listGroups() throws ExternalIdentityException {
        log.debug("listGROUP");
        return null;
    }

    public ExternalUser authenticate( Credentials credentials) throws ExternalIdentityException, LoginException {
        log.debug("START of AUTH");
        if (!(credentials instanceof SimpleCredentials)) {
            throw new LoginException("invalid credentials class " + credentials.getClass());
        }

        try{

            log.debug("START of AUTH");

            SimpleCredentials sc = (SimpleCredentials) credentials;
            String username = sc.getUserID();
            String password = new String(sc.getPassword());
            log.debug("getting token:" + server + " , email:" + sc.getUserID());
            String token = identityConnector.getToken(username, password);
            log.debug("got token:" + server + " , email:" + sc.getUserID());


            MagentoCustomer customer = identityConnector.getCustomer(token);

            ExternalIdentityRef ref = new ExternalIdentityRef(customer.email, getName());

            HashMap<String, Object> properties = new HashMap<String, Object>();

            properties.put("id", customer.email);
            properties.put("fullname", customer.firstname + " " + customer.lastname);
            properties.put("givenname", customer.firstname);
            properties.put("familyname", customer.lastname);
            properties.put("email", customer.email);
            properties.put("store-id", customer.store_id);
            properties.put("magento-user-id", customer.id);
            properties.put("token", token);
            properties.put("gender", customer.gender);
            String groupName = identityConnector.getGroupName(customer.group_id, adminToken);
            properties.put("groups", "[" + groupName + "]");

            ExternalUser user = new ExternalUserImpl(getName(), ref, customer.email, properties);
            log.debug("USER:" + user);
            return user;

        } catch (Exception e) {
            log.error("Error Authenticating user:" + e);

            throw new LoginException("invalid user or password");
        }
    }

    private boolean isMyRef( ExternalIdentityRef ref) {
        log.debug("isMyREF");

        final String refProviderName = ref.getProviderName();
        return refProviderName == null || getName().equals(refProviderName);
    }


}
