package com.infield.magento.core.connector.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MagentoAddress {
        public final String region_code;
        public final String country_id;
        public final String[] street;
        public final String telephone;
        public final String postcode;
        public final String city;
        public final String firstname;
        public final String lastname;

        @SuppressWarnings("PackageAccessibility")
        @JsonCreator
        public MagentoAddress(@JsonProperty("region_code") String region_code, @JsonProperty("country_id") String country_id, @JsonProperty("street") String[] street, @JsonProperty("telephone") String telephone, @JsonProperty("postcode") String postcode, @JsonProperty("city") String city, @JsonProperty("firstname") String firstname, @JsonProperty("lastname") String lastname){
            this.region_code = region_code;
            this.country_id = country_id;
            this.street = street;
            this.telephone = telephone;
            this.postcode = postcode;
            this.city = city;
            this.firstname = firstname;
            this.lastname = lastname;
        }
}


