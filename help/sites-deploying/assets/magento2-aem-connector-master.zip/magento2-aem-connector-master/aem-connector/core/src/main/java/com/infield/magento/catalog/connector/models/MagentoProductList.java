package com.infield.magento.catalog.connector.models;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public final class MagentoProductList {


    public MagentoProduct[] getItems() {
        return items;
    }

    public void setItems(MagentoProduct[] items) {
        this.items = items;
    }

    public void setSearch_criteria(Search_criteria search_criteria) {
        this.search_criteria = search_criteria;
    }

    public void setTotal_count(long total_count) {
        this.total_count = total_count;
    }

    @JsonProperty("items")
    public  MagentoProduct items[];

    @JsonProperty("search_criteria")
    public Search_criteria search_criteria;

    @JsonProperty("total_count")
    public long total_count;

public MagentoProductList() {
    }

    @JsonCreator
    public MagentoProductList(@JsonProperty("items") MagentoProduct[] items, @JsonProperty("search_criteria") Search_criteria search_criteria, @JsonProperty("total_count") long total_count){
        this.items = items;
        this.search_criteria = search_criteria;
        this.total_count = total_count;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Search_criteria {
        public final Filter_group filter_groups[];
        public final long page_size;
        public final long current_page;

        @JsonCreator
        public Search_criteria(@JsonProperty("filter_groups") Filter_group[] filter_groups, @JsonProperty("page_size") long page_size, @JsonProperty("current_page") long current_page){
            this.filter_groups = filter_groups;
            this.page_size = page_size;
            this.current_page = current_page;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static final class Filter_group {

            @JsonCreator
            public Filter_group(){
            }
        }
    }



    public Search_criteria getSearch_criteria() {
        return search_criteria;
    }

    public long getTotal_count() {
        return total_count;
    }

    public boolean isLast(){
        return (this.search_criteria.current_page >= maxPages());
    }

    public long maxPages(){

        return this.total_count / this.search_criteria.page_size;

    }

    public long getNextPage(){
        return this.search_criteria.current_page + 1;
    }

    public List<MagentoProduct> getProducts(){
        return Arrays.asList(items);
    }

    public HashMap<String, MagentoProduct> getItemMap(){

        HashMap<String, MagentoProduct> itemsHash = new HashMap<String, MagentoProduct>();
        for(MagentoProduct product: items){
            itemsHash.put(product.sku, product);
        }
        return itemsHash;
    }





}
