package com.infield.magento.catalog.connector.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class MagentoProductVariant {
    public final String sku;
    public final String name;
    public final long attribute_set_id;
    public final BigDecimal price;
    public final long status;
    public final long visibility;
    public final String type_id;
    public final String created_at;
    public final String updated_at;
    public final long weight;
    public final Product_link product_links[];
    public final Option options[];
    public final Tier_price tier_prices[];
    public final Custom_attribute custom_attributes[];

    @JsonCreator
    public MagentoProductVariant(@JsonProperty("sku") String sku, @JsonProperty("name") String name, @JsonProperty("attribute_set_id") long attribute_set_id, @JsonProperty("price") BigDecimal price, @JsonProperty("status") long status, @JsonProperty("visibility") long visibility, @JsonProperty("type_id") String type_id, @JsonProperty("created_at") String created_at, @JsonProperty("updated_at") String updated_at, @JsonProperty("weight") long weight, @JsonProperty("product_links") Product_link[] product_links, @JsonProperty("options") Option[] options, @JsonProperty("tier_prices") Tier_price[] tier_prices, @JsonProperty("custom_attributes") Custom_attribute[] custom_attributes){
        this.sku = sku;
        this.name = name;
        this.attribute_set_id = attribute_set_id;
        this.price = price;
        this.status = status;
        this.visibility = visibility;
        this.type_id = type_id;
        this.created_at = created_at;
        this.updated_at = updated_at;
        this.weight = weight;
        this.product_links = product_links;
        this.options = options;
        this.tier_prices = tier_prices;
        this.custom_attributes = custom_attributes;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Product_link {

        @JsonCreator
        public Product_link(){
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Option {

        @JsonCreator
        public Option(){
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Tier_price {

        @JsonCreator
        public Tier_price(){
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static final class Custom_attribute {
        public final String attribute_code;
        public final List value;

        @JsonCreator
        public Custom_attribute(@JsonProperty("attribute_code") String attribute_code, @JsonProperty("value") List value){
            this.attribute_code = attribute_code;
            this.value = value;
        }
    }


    public String getAttributeId(String attibuteCode){
        for(Custom_attribute attribute: custom_attributes){
            if(attribute.attribute_code.equalsIgnoreCase(attibuteCode)) {
                return (String)attribute.value.get(0);
            }
        }
        return null;
    }





}
