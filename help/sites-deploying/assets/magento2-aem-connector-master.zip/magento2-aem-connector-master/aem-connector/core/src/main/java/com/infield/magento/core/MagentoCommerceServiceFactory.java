package com.infield.magento.core;

import com.adobe.cq.commerce.api.CommerceService;
import com.adobe.cq.commerce.api.CommerceServiceFactory;
import com.adobe.cq.commerce.common.AbstractJcrCommerceServiceFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;


@Component
@Service
@Properties(value = {
    @Property(name = "service.description", value = "Magento2 Commerce Provider"),
    @Property(name = "commerceProvider", value = "magento", propertyPrivate = true)
})
public class MagentoCommerceServiceFactory extends AbstractJcrCommerceServiceFactory implements CommerceServiceFactory {

    public CommerceService getCommerceService(Resource res) {
        return new MagentoCommerceServiceImpl(getServiceContext(), res);
    }
}
