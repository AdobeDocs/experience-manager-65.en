package com.infield.magento.catalog.importer;

import com.day.cq.polling.importer.ImportException;
import com.day.cq.polling.importer.Importer;
import com.infield.magento.catalog.connector.MagentoConnectorService;
import com.infield.magento.catalog.connector.models.MagentoProduct;
import com.infield.magento.catalog.connector.models.MagentoProductList;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

@Component(metatype = false, enabled= true, label = "Magento 2 Catalog Updater")
@Service(Importer.class)
@Properties(value = {
    @Property(name = "service.description", value = "Magento 2 Catalog Updater"),
    @Property(name = "service.vendor", value = "Infield Digital"),
    @Property(name = Importer.SCHEME_PROPERTY, value = "magento")
})
public class MagentoCatalogUpdater implements Importer {
    private static final Logger log = LoggerFactory.getLogger(MagentoCatalogUpdater.class);
    public void importData(String scheme, String dataSource, Resource target) throws ImportException {

    }

    @Override
    public void importData(String schema, String datasource, Resource resource, String login, String password) throws ImportException {

        ResourceResolver resourceResolver = resource.getResourceResolver();
        Node baseNode = resource.adaptTo(Node.class);
        log.debug("baseNode for Catalog Updater:" + baseNode);

        String lastImport = "";

        try {
            lastImport = baseNode.getProperty("lastImport").getString();
        } catch (RepositoryException e) {
            log.debug("lastImport not found !");

            Calendar cal = Calendar.getInstance();
            SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            lastImport = format1.format(cal.getTime()) + ":00";;
            log.debug("New Times is " + lastImport);
        }

        String storePath = resource.getPath();
        MagentoConnectorService connectorService = new MagentoConnectorService(datasource, login, password);
        MagentoProductImporter productImporter = new MagentoProductImporter(connectorService);

        String token = null;
        try {

            token = connectorService.getToken();
            log.debug("Getting Token " + token);
        } catch (Exception e) {
            e.printStackTrace();
        }

        MagentoProductList response = connectorService.updateProductList(lastImport);
        log.debug("Number of Items " + response.getItems().length);

        for(MagentoProduct item: response.getItems()){

            Resource productResource = resourceResolver.getResource(getProductPath(storePath, item.sku));
            if (productResource == null) {
                log.debug("New Product: " +item.toString());
                try {
                    productImporter.addProduct(resourceResolver, resource.getPath(), item.sku, item);
                } catch (RepositoryException e) {
                    e.printStackTrace();
                    log.debug("Failed to import Product:" + item.sku);
                }

            } else {
                log.debug("Updating Product: " +item.toString());
                productImporter.updateProduct(resourceResolver, resource.getPath(), item.sku, item);
            }
        }

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        lastImport  = format1.format(cal.getTime()) + ":00";

        try {
            baseNode.setProperty("lastImport", lastImport);
            //todo: need to change to new session based save
            baseNode.save();
        } catch (RepositoryException e) {
            log.debug("Error Setting lastImport:" + e);
            e.printStackTrace();
        }
    }

    protected String getProductPath(String storePath, String sku) {

        String productSKU = sku;
        boolean variation = false;

        if (sku.contains(".")) {
            productSKU = sku.substring(0, sku.indexOf("."));
            variation = true;
        }

        String path = storePath + "/" + sku.substring(0, 2) + "/" + sku.substring(0, 4) + "/" + productSKU;
        if (variation) {
            path += "/" + sku;
        }
        return path;
    }


}
