#Magento 2 => AEM Connector
========

## Requirements
1. Running AEM 6.2 installation
2. Running Magento 2 instance
3. Apache maven
4. We.Retail needs to be built

##Basic setup (author instance)

1. Install we.retail [content package](https://github.com/Adobe-Marketing-Cloud/aem-sample-we-retail/releases) 
2. Build [we.retail code](https://github.com/Adobe-Marketing-Cloud/aem-sample-we-retail) to author instance
3. Build Connector (`mvn clean install` with `autoInstallPackage` profile)

##"Gotchas"

####Set Commerce Provider

After building the AEM Connector to your local author instance there are a number of "gotchas" that are easily missed if you're unfamilir with the commerce system within AEM.

First, you will need to be sure to set the `cq:commerceProvider`,  `cq:checkoutPage`, and `cq:commerceType` properties in a parent node to your catalog rollout location. There are a number of ways this can be done, but one way is to simply manually add these properties as seen below.

![set commerce provider](documentation/images/set_commerce.png)

####Manually import Magento images (if applicable)

By default the AEM Connector will import the base image *path* from Magento, but it does not actually import the asset itself. This is because there are many different strategies for dealing with assets and many integrators may choose to not use images from Magento at all, and may choose instead to manage assets completely within AEM. If this is not the case, you can still easily import the images from Magento into AEM by copy the `<magento root>/pub/media/catalog/product` folder from your Magento installation into the DAM path `/content/dam/magento2/product` - if this is completed then the image paths the importer grabbed should match up with the path within the DAM.

##Install / Configure Identity provider

The identity provider allows both authentication with and creation of Magento 2 customers. Currently there is a limited built in functionality within We.Retail however components can be built using the included classes / CIF implementations which will allow for authenticating wth Magento 2. 

#### 1. build the bundle

- build and install the bundle with `mvn clean install ` using the autoInstallPackagePublish Profiles
This will build the bundle and automatically deploy it into an AEM instance running at localhost:4503 or localhost:4503.


#### 2. configure the identity provider
Next we need to create a configuration for our new IDP.

- open the [Felix Configuration Manager](http://localhost:4503/system/console/configMgr) and search for the _"magento identity provider"_ factory config and click on the plus **+** button.

![create magento idp](documentation/images/shot1.png)

Enter the following information:


| Name          | Value              |
|---------------|--------------------|
| Server        | magento Server     |
| Username      | Magento Admin Username |



#### 3. configure the sync handler

- open the [Felix Configuration Manager](http://localhost:4503/system/console/configMgr) and search for the _"Default Sync Handler"_ factory config and click on the plus **+** button.

![find sync handler](documentation/images/step2.png)

Enter the following information:

| Name                          | Value
|-------------------------------|--------------------
| Sync Handler Name             | `default`
| User Expiration Time          | `1m`
| User auto membership          | `everyone`
| User property mapping         | `rep:fullname=cn`  `profile/nt:primaryType="nt:unstructured"`  `profile/givenName=givenname`  `profile/familyName=familyname`  `profile/email=email`  `magento-token=token`  |
| User Path Prefix              | `/magento`
| User Membership Expiration	 | `1h`
| User membership nesting depth	 | `0`
| Group Expiration Time         | `1d`
| Group auto membership         |
| Group property mapping        |
| Group Path Prefix             | `/magento`



#### 4. configure the external login module
The external login module is the bridge between the login, the idp and the sync handler. so add a new configuration that pairs the new `magento` idp with the `default` sync handler

- open the [Felix Configuration Manager](http://localhost:4503/system/console/configMgr) and search for the _"External Login Module"_ factory config and click on the plus **+** button.


Enter the following information:

| Name                   | Value
|------------------------|----------
| JAAS Ranking           | 50
| JAAS Control Flag      | `SUFFICIENT`
| JAAS Realm             |
| Identity Provider Name | `magento`
| Sync Handler Name      | `default`

And save the config

![configure loginmodule](documentation/images/shot3.png)

#### 4. Create a Registration Form

#### 5. Configure the Importer.


#### 6. Configure the Order-Service.

Add a new mapping to Apache Sling Service User Mapper Service Amendment

com.infield.aem.magento2.core:orders=commerce-orders-service





#### 7. test that it works
- ensure to logout previous session or clear all browser cookie or use a different browser, hostname or IP
- open browser to aem: http://127.0.0.1:4503/
- login with an account that exists on Magento

Looking at the users and groups should show the group _everyone_ and his member(s):

- open the [AEM useradmin](http://localhost:4503/useradmin)
- search for your new user







