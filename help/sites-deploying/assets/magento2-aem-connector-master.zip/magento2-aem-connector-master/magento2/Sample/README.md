# AEM + Magento 2 Sample Integration module

This module provides two key features:

1. A simple mechanism to allow AEM to transfer a checkout / cart session to Magento 2 
2. A *very* simple theme to override the checkout page styling to better match the We.Retail look / feel

