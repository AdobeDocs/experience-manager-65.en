package mergeandfuse.com;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;

@Component(metatype = true, immediate = true, label = "RemoteFunctionImpl")
@Service(value = RemoteFunction.class)
@org.apache.felix.scr.annotations.Properties({
		@org.apache.felix.scr.annotations.Property(name = "connectors.jsoninvoker", boolValue = true),
		@org.apache.felix.scr.annotations.Property(name = "connectors.jsoninvoker.alias", value = "test1"),
		@org.apache.felix.scr.annotations.Property(name = "connectors.httpinvoker", boolValue = true),
		@org.apache.felix.scr.annotations.Property(name = "connectors.httpinvoker.alias", value = "test1"),
		@org.apache.felix.scr.annotations.Property(name = "connectors.remoting", boolValue = true),
		@org.apache.felix.scr.annotations.Property(name = "connectors.remoting.id", value = "test1"),
		@org.apache.felix.scr.annotations.Property(name = "exm.service", boolValue = true)})
public class RemoteFuntionImpl implements RemoteFunction {

	@Override
	public String toAllCaps(String name) {
		System.out.println("######Got######"+name);
		
		return name.toUpperCase();
	}
	
}
