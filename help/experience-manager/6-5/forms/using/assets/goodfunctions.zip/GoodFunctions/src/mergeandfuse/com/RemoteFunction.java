package mergeandfuse.com;
import com.adobe.exm.expeval.ServiceMethod;

public interface RemoteFunction {
	@ServiceMethod(enabled=true,displayName="Returns_all_caps",description="Function to convert to all CAPS", familyId="remote")
	public String toAllCaps(String name);
	
}
