(function(window, hobs) {
    'use strict';
    window.testsuites = window.testsuites || {};
 	// Registering the test form suite to the sytem
 	// If there are other forms, all registration should be done here
    window.testsuites.testForm = new hobs.TestSuite("testForm", {
        register: false
    });
	// window.testsuites.testForm1 = new hobs.TestSuite("testForm1");
}(window, window.hobs));
