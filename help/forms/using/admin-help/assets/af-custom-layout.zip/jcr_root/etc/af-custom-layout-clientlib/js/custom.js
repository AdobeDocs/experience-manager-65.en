var toggleNav = function () {

    var nav = $('.custom-navigation');
    if (nav) {
        nav.toggleClass('nav-close');
    }
}

$(window).on('load', function() {
    if (window.guideBridge) {
        window.guideBridge.on("elementNavigationChanged",
        function (evntName, evnt) {
                    var activePanelSom = evnt.newText,
                        activePanel = window.guideBridge._guideView.getView(activePanelSom);
                    $('.panel-name').html(activePanel.$itemNav.find('a').html());
                }
        );
    }
});