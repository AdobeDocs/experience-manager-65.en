/*******************************************************************************
 * ADOBE CONFIDENTIAL
 *  ___________________
 *
 *   Copyright 2013 Adobe Systems Incorporated
 *   All Rights Reserved.
 *
 *  NOTICE:  All information contained herein is, and remains
 *  the property of Adobe Systems Incorporated and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to Adobe Systems Incorporated and its
 *  suppliers and are protected by all applicable intellectual property
 *  laws, including trade secret and copyright laws.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from Adobe Systems Incorporated.
 ******************************************************************************/

(function(xfalib){
xfalib.locale.Strings =
{
    "pleaseTapText"         :       "Por favor pulse aquí para inscribirse",
	"pleaseClickText"       :       "Haga clic aquí para registrarte",
	"clearSignature"        :       "Borrar confirmación de la firma",
	"clearSignatureConfirm" :       "¿Está seguro que desea borrar la firma?",
	"fetchGeoLocation"      :       "Info Fetching Ubicación geográfica ...",
	"errorFetchGeoLocation" :       "Error al obtener información de geolocalización",
	"pleaseSignText"        :       "Por favor, firme aquí",
	"latitude"              :       "Latitud",
	"longitude"             :       "Longitud",
	"time"                  :       "Tiempo",
    "clearText"             :       "Claro",
    "validationIssue"       :       "Error de validación en el campo",
    "warning"               :       "Advertencias",
    "errors"                :       "Errores",
    "errorServerScript"     :       "Error en el funcionamiento de script de servidor",
    "unableToConnectText"   :       "No se pudo conectar con el servidor",
    "errorSubmittingForm"   :       "Error presentar formulario para url interna",
    "ok"                    :       "Bueno",
    "cancel"                :       "Cancelar",
    "yes"                   :       "Sí",
    "no"                    :       "No",
    "clear"                 :       "Claro",
    "brushes"               :       "Pinceles",
    "geolocation"           :       "Geolocalización"
}
})(xfalib);
