/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

(function (guidelib) {
    guidelib.i18n.strings = {
        "FormModelUpdated" : "Esquema / plantilla de formulario para este Formulario de adaptación ha sido actualizado",
        "SyncFormModel" : "para reajustar con nueva versión",
        "ClickHere": "Haga clic aquí",
        "FileCloseAccessText": "Pulse Enter para borrar el archivo "
    };
    guidelib.i18n.LogMessages = {
        "AEM-AF-901-001"   :   "[AEM-AF-901-001]: Error al recuperar el estado formulario.",
        "AEM-AF-901-002"   :   "[AEM-AF-901-002]: Los archivos {0} son mayores que el tamaño esperado: {1} MB.",
        "AEM-AF-901-003"   :   "[AEM-AF-901-003]: No se puede conectar al servidor.",
        "AEM-AF-901-004"   :   "[AEM-AF-901-004]: Se ha encontrado un error interno al enviar el formulario.",
        "AEM-AF-901-005"   :   " Este campo es un campo obligatorio.",
        "AEM-AF-901-006"   :   " Hay un error de validación en el campo.",
        "AEM-AF-901-007"   :   " El campo está lleno en el formato esperado.",
        "AEM-AF-901-008"   :   " El servidor no es accesible",
        "AEM-AF-901-009"   :   " Un error ocurrió al proyecto de ahorro",
        "AEM-AF-901-010"   :   "Verifique sólo funciona con las formas de adaptación basadas en XFA.",
        "AEM-AF-901-011"   :   "Error al restaurar el estado de forma.",
        "AEM-AF-901-012"   :   "No se pudo recuperar el estado formulario.",
        "AEM-AF-901-013"   :   "Correo electrónico del usuario no definido. No se puede generar PDF signable.",
        "AEM-AF-901-014"   :   "XDP título o el título Guía indefinido. No se puede generar PDF signable.",
        "AEM-AF-901-015"   :   "Error al enviar el guía: ",
        "AEM-AF-901-016"   :   "Ningún campo de firma en el formulario. Por favor, continúe!",
        "AEM-AF-901-017"   :   "No se pudo obtener datos XML de formulario HTML: ",
        "AEM-AF-901-018"   :   "Por favor, firmar todos los campos obligatorios",
        "AEM-AF-901-019"   :   "Por favor, esign el formulario.",
        "AEM-AF-901-020"   :   "Enviando el formulario ..."
    };
})(guidelib);
