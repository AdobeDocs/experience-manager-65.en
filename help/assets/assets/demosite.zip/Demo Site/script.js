

function simpleMessage() {
	alert("This is just an alert box");
}



// settimeout is in milliseconds



var imageArray = ["http://localhost:4502/content/dam/geometrixx-tours/6.jpg","http://localhost:4502/content/dam/geometrixx-tours/13.jpg","http://localhost:4502/content/dam/geometrixx-tours/20.jpg",
				  "http://localhost:4502/content/dam/geometrixx-tours/4.jpg","http://localhost:4502/content/dam/geometrixx-tours/12.jpg","http://localhost:4502/content/dam/geometrixx-tours/15.jpg"];

var assetID = ["c4ae1d08-4934-4394-95d1-735eca2af5ad","6445a57b-4575-4846-b221-eeaccbe664d1","3c0525ac-094a-4cb9-b1d5-29d0fe11876d",
				"de19d95e-0c33-4c33-985c-f902151f18a2","0bb377a2-eec6-4c52-aeab-4c402ec653f4","3396b3cf-5488-4cc8-9eb1-c292189921c9"];
var imageIndex = 0;
var assetIDIndex = 0;
var myImage = document.getElementById("mainImage");
var myDiv = document.getElementById("mainImage");

function changeImage() {
	
	myImage.setAttribute("src",imageArray[imageIndex]);
	myDiv.setAttribute("data-aem-asset-id",assetID[assetIDIndex]);

	imageIndex++;
	assetIDIndex++;
	if (imageIndex >= imageArray.length) {
		imageIndex = 0;
	}
	if (assetIDIndex >= imageArray.length) {
		assetIDIndex = 0;
	}
}


setInterval(changeImage,3000);

